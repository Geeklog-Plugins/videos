<?php

$LANG_VIDEOS = array(
    'plugin_name' => 'Videos',
    'curation_failed' => 'Unable to save this editorial decision.',
    'curation_saved' => 'Editorial decision saved.',
    'search_type_label' => 'Videos',
    'admin_title' => 'Videos administration',
    'public_title' => 'Videos',
    'my_videos' => 'My videos',
    'catalogue' => 'Video catalogue',
    'rankings' => 'Rankings',
    'video_navigation' => 'Video navigation',
    'rating_saved' => 'Your rating has been saved.',
    'rating_error' => 'The rating could not be saved.',
    'rating_delete' => 'Delete my rating',
    'rating_delete_confirm' => 'Delete your rating for this video? The viewing history will be preserved.',
    'rating_deleted' => 'Your rating has been deleted.',
    'rating_delete_error' => 'Your rating could not be deleted.',
    'history_rating_deleted' => 'Your rating has been deleted. The video remains in your viewing history.',
    'history_rating_delete_failed' => 'Your rating could not be deleted. Please try again.',
    'copy_link' => 'Copy link',
    'native_share' => 'Share',
    'link_copied' => 'Link copied.',
    'rating_locked' => 'Start watching the video to enable rating.',
    'rating_waiting' => 'Rating will be enabled after the viewing threshold.',
    'playback_error' => 'Playback tracking is unavailable.',
    'rating_countdown' => 'Rating available in %d seconds.',
    'all_videos' => 'All',
    'watched_videos' => 'Watched',
    'rated_videos' => 'Rated',
    'watch_again' => 'Watch again',
    'your_rating' => 'Your rating',
    'local_average' => 'Local average',
    'personal_views' => 'Personal views',
    'watched_on' => 'Watched on',
    'no_personal_videos' => 'No video matches this filter.',
    'manage_personal_data' => 'Manage my video data',
    'manage_personal_data_help' => 'Download your stored video data or permanently delete your personal history and ratings.',
    'export_personal_data' => 'Download my data (JSON)',
    'delete_personal_data' => 'Delete my video data',
    'delete_personal_data_checkbox' => 'I understand that my personal video history and ratings will be permanently deleted.',
    'delete_personal_data_confirm' => 'Permanently delete your personal video history and ratings? This action cannot be undone.',
    'history_deleted' => 'Your personal video history and ratings have been deleted.',
    'history_delete_failed' => 'Some personal video data could not be deleted. Please try again or contact the site administrator.',
    'history_delete_denied' => 'Personal data deletion is disabled by the administrator.',
    'history_delete_confirm' => 'You must confirm the permanent deletion.',
    'history_export_failed' => 'Your video data could not be exported.',
    'history_export_denied' => 'Personal data export is disabled by the administrator.',
    'history_csrf' => 'The security token has expired. Please try again.',
    'cache_maintenance' => 'YouTube cache maintenance',
    'cache_scope' => 'Cache to clear',
    'cache_search' => 'Search results',
    'cache_videos' => 'Video information',
    'cache_channels' => 'Channel information',
    'cache_availability' => 'Availability checks',
    'cache_all' => 'All YouTube caches',
    'cache_clear' => 'Clear selected cache',
    'cache_confirm' => 'Clear the selected YouTube cache? Views, ratings and histories will be preserved.',
    'cache_cleared' => '%d cache entries were deleted.',
    'cache_clear_partial' => '%d entries were deleted, but %d files could not be removed.',
    'cache_clear_denied' => 'You do not have permission to clear the cache.',
    'cache_entries' => 'Entries',
    'cache_size' => 'Size',
    'cache_latest' => 'Latest entry',
    'quota_status' => 'YouTube API activity today',
    'quota_search_calls' => 'Search calls',
    'quota_video_calls' => 'Video detail calls',
    'quota_channel_calls' => 'Channel detail calls',
    'quota_last_search' => 'Last search',
    'quota_last_success' => 'Last API success',
    'quota_last_error' => 'Last API error',
    'never' => 'Never',
    'already_watched' => 'Already watched',
    'catalogue_page' => 'Page %d of %d',
    'previous_page' => 'Previous',
    'next_page' => 'Next',
    'video_duration' => 'Duration',
    'no_more_videos' => 'No other video is available on this page.',
    'global_ranking' => 'Global video ranking',
    'ranking_rebuild' => 'Rebuild video and channel rankings',
    'ranking_confirm' => 'Rebuild the video and channel rankings from the existing JSON statistics?',
    'ranking_rebuilt' => 'The rankings were rebuilt with %d videos and their channels.',
    'ranking_rebuild_failed' => 'The video and channel rankings could not be rebuilt.',
    'ranking_score' => 'Score',
    'ranking_views' => 'Views',
    'ranking_watch_rate' => 'Ratio when the view qualified',
    'recommendation_accepted' => 'Chosen as next',
    'recommendation_skipped' => 'Skipped',
    'ranking_no_data' => 'No ranked video is available yet.',
    'channel_ranking' => 'Local channel ranking',
    'channel_ranking_no_data' => 'No ranked channel is available yet.',
    'channel' => 'Channel',
    'channel_videos' => 'Distinct videos',
    'public_rankings_title' => 'Video and channel rankings',
    'public_rankings_intro' => 'Discover the videos and channels most appreciated by this site’s visitors.',
    'public_rankings_disabled' => 'The public rankings page is disabled.',
    'public_rankings_unavailable' => 'The rankings are temporarily unavailable.',
    'public_rankings_empty' => 'No public ranking is currently enabled.',
    'top_videos' => 'Top videos',
    'top_channels' => 'Top channels',
    'ranking_tabs_navigation' => 'Choose a ranking',
    'next_video' => 'Next video',
    'next_video_help' => 'Suggested from the current topic and local rankings.',
    'another_suggestion' => 'Another suggestion',
    'watch_next' => 'Watch this video',
    'no_next_video' => 'No suitable next video is currently available.',
    'block_title' => 'Recommended videos',
    'block_title_recommended' => 'Recommended videos',
    'block_title_top_rated' => 'Best weighted ratings',
    'block_title_most_watched' => 'Most watched videos',
    'block_title_recent_activity' => 'Recently watched videos',
    'block_title_best_channels' => 'Best local channels',
    'block_metric_recommended' => 'Combined local score: %s',
    'block_metric_weighted_rating' => 'Weighted rating: %s/5 (%d ratings)',
    'block_metric_views' => '%d qualified views',
    'block_metric_last_viewed' => 'Last local view: %s',
    'block_metric_channel' => '%s/5 · %d videos · %d views',
    'block_mode_recommended' => 'Recommended for this site',
    'block_mode_top_rated' => 'Best weighted local ratings',
    'block_mode_most_watched' => 'Most qualified local views',
    'block_mode_recent_activity' => 'Recently watched on this site',
    'block_mode_random' => 'Random selection from local videos',
    'block_mode_best_channels' => 'Best locally ranked channels',
    'view_video_catalogue' => 'View the video catalogue',
    'view_channel_ranking' => 'View the channel ranking',
    'access_denied' => 'You do not have permission to access this page.',
    'development_version' => 'This development version is not ready for public use.',
    'moderation_title' => 'Video and channel moderation',
    'moderation_storage_error' => 'The moderation storage cannot be initialized.',
    'moderate_video' => 'Moderate a video',
    'moderate_channel' => 'Manage a channel',
    'moderated_videos' => 'Active video decisions',
    'moderated_channels' => 'Active channel decisions',
    'video_id' => 'YouTube video ID',
    'channel_id' => 'YouTube channel ID',
    'moderation_state' => 'State',
    'moderation_reason' => 'Internal reason',
    'moderation_save' => 'Save decision',
    'moderation_saved' => 'The moderation decision has been saved.',
    'moderation_invalid' => 'The identifier or moderation state is invalid.',
    'moderation_state_neutral' => 'Neutral (remove decision)',
    'moderation_state_allowed' => 'Allowed',
    'moderation_state_priority' => 'Priority',
    'moderation_state_blocked' => 'Blocked',
    'moderation_state_disabled' => 'Disabled',
    'moderation_item' => 'Item',
    'moderation_date' => 'Date',
    'moderation_action' => 'Action',
    'moderation_remove' => 'Return to neutral',
    'moderation_neutral_confirm' => 'Remove this moderation decision?',
    'moderation_no_records' => 'No active moderation decision.',
    'moderation_quick_actions' => 'Moderation actions',
    'moderation_block_video' => 'Block video',
    'moderation_block_channel' => 'Block channel',
    'moderation_block_video_confirm' => 'Block this video and immediately remove it from the plugin?',
    'moderation_block_channel_confirm' => 'Block this channel and remove all its videos from the plugin?',
    'moderation_quick_reason_video' => 'Blocked from the watch page',
    'moderation_quick_reason_channel' => 'Blocked from the watch page',
    'moderation_quick_failed' => 'The moderation decision could not be saved.',
    'cancel' => 'Cancel',
    'known_channel' => 'Channel known to the plugin',
    'choose_known_channel' => 'Select a channel by name',
    'known_channel_help' => 'Channels come from YouTube searches already performed by the plugin.',
    'known_channel_empty' => 'No channel is known yet. Run a bootstrap search, then return to this page.',
    'manual_channel_entry' => 'Advanced UC… identifier entry',
    'permanent_pool_badge' => 'Permanent selection',
    'permanent_pool_title' => 'Permanent catalogue pool',
    'permanent_pool_count' => 'Retained videos',
    'permanent_pool_excluded_count' => 'Videos excluded from pool',
    'permanent_pool_last_rebuild' => 'Last rebuild',
    'permanent_pool_video_id' => 'Video ID to pin',
    'permanent_pool_pin' => 'Pin',
    'permanent_pool_rebuild' => 'Rebuild pool',
    'permanent_pool_remove' => 'Remove',
    'permanent_pool_exclude' => 'Remove and exclude',
    'permanent_pool_allow' => 'Allow again',
    'permanent_pool_excluded_list' => 'Manually excluded videos',
    'permanent_pool_source' => 'Source',
    'permanent_pool_source_manual' => 'Manual pin',
    'permanent_pool_source_automatic' => 'Automatic admission',
    'permanent_pool_action_saved' => 'The permanent pool has been updated.',
    'permanent_pool_action_failed' => 'The permanent pool could not be updated.',
    'permanent_pool_confirm' => 'Confirm this permanent pool change?',
    'discovery_seed_query' => 'Reservoir topic',
    'discovery_seed_button' => 'Seed or enrich reservoir',
    'discovery_seed_confirm' => 'Seeding may consume several hundred YouTube quota units. Continue?',
    'discovery_seed_success' => '%d new video(s), %d total, from %d successful search(es).',
    'discovery_seed_failed' => 'The reservoir could not be enriched. Check the key, quota and log.',
    'discovery_count' => 'Videos in discovery reservoir',
    'discovery_last_refresh' => 'Last refresh',
    'discovery_last_seed' => 'Last full seed',
    'storage_active_path' => 'Active persistent data directory',
    'storage_legacy_path' => 'Preserved legacy directory',
    'storage_migration_result' => 'Storage migration',
    'storage_migration_counts' => '%d file(s) copied, %d already present, %d skipped as invalid or unreadable',
    'video' => 'Video',
    'seo_diagnostic' => 'SEO metadata preview',
    'seo_diagnostic_help' => 'Preview generated from the first locally ranked video. It makes no YouTube API call.',
    'seo_diagnostic_empty' => 'No cached ranked video is available for the preview yet.',
    'faq_title' => 'Frequently asked questions',
    'video_about_title' => 'About this video'
);







































// 0.19.0 unified admin interface strings
$LANG_VIDEOS['admin_actions_column'] = 'Actions';
$LANG_VIDEOS['admin_cache_label'] = 'Cache';
$LANG_VIDEOS['admin_yes'] = 'Yes';
$LANG_VIDEOS['admin_no'] = 'No';
$LANG_VIDEOS['admin_status_ok'] = 'OK';
$LANG_VIDEOS['admin_remove_help'] = 'removes the video from the permanent catalogue, but it may be selected again.';
$LANG_VIDEOS['admin_exclude_help'] = 'prevents it from being added again until it is explicitly allowed.';
$LANG_VIDEOS['admin_consult'] = 'See';
$LANG_VIDEOS['admin_byte_unit'] = 'B';
// END 0.19.0 unified admin interface strings

// 0.18.0 interface strings
$LANG_VIDEOS['admin_nav_overview'] = 'Overview';
$LANG_VIDEOS['admin_nav_actions'] = 'Actions';
$LANG_VIDEOS['admin_nav_stats'] = 'Statistics';
$LANG_VIDEOS['admin_nav_moderation'] = 'Moderation';
$LANG_VIDEOS['admin_navigation'] = 'Videos administration';
$LANG_VIDEOS['catalogue_disabled'] = 'The video catalogue is disabled.';
$LANG_VIDEOS['catalogue_unavailable'] = 'The video catalogue is temporarily unavailable.';
$LANG_VIDEOS['catalogue_search_unavailable'] = 'Video search is temporarily unavailable.';
$LANG_VIDEOS['catalogue_search_empty'] = 'No catalogue video matches this search.';
$LANG_VIDEOS['catalogue_topic_required'] = 'The video topic must be configured by an administrator.';
$LANG_VIDEOS['catalogue_none_available'] = 'No videos are currently available.';
$LANG_VIDEOS['catalogue_search_label'] = 'Search the catalogue';
$LANG_VIDEOS['catalogue_search_placeholder'] = 'Title, channel or keywords';
$LANG_VIDEOS['catalogue_search_button'] = 'Search';
$LANG_VIDEOS['catalogue_search_help'] = 'Search uses videos already known to this site and consumes no additional YouTube quota.';
$LANG_VIDEOS['catalogue_search_results'] = 'result(s) for “%s”.';
$LANG_VIDEOS['catalogue_show_all'] = 'Show the full catalogue';
$LANG_VIDEOS['catalogue_search_page_title'] = 'Search “%s”';
$LANG_VIDEOS['channel_unavailable'] = 'Video channel unavailable.';
$LANG_VIDEOS['channel_temporarily_unavailable'] = 'Video channel temporarily unavailable.';
$LANG_VIDEOS['channel_not_published'] = 'This channel is not published.';
$LANG_VIDEOS['channel_insufficient_selection'] = 'This channel does not yet have a sufficient editorial selection.';
$LANG_VIDEOS['channel_meta_fallback'] = 'Discover noteworthy videos from %s selected in %s.';
$LANG_VIDEOS['channel_priority_badge'] = 'Priority channel';
$LANG_VIDEOS['channel_pinned_video'] = 'pinned video';
$LANG_VIDEOS['channel_pinned_videos'] = 'pinned videos';
$LANG_VIDEOS['channel_information'] = 'Channel information';
$LANG_VIDEOS['channel_subscribers'] = 'Subscribers';
$LANG_VIDEOS['channel_youtube_views'] = 'YouTube views';
$LANG_VIDEOS['channel_youtube_videos'] = 'Videos on YouTube';
$LANG_VIDEOS['channel_local_videos'] = 'Noteworthy local videos';
$LANG_VIDEOS['channel_permanent_selection'] = 'Permanent selection';
$LANG_VIDEOS['channel_created'] = 'Channel created';
$LANG_VIDEOS['channel_about'] = 'About the channel';
$LANG_VIDEOS['channel_view_youtube'] = 'View channel on YouTube';
$LANG_VIDEOS['channel_featured_videos'] = 'Noteworthy videos';
$LANG_VIDEOS['channel_pinned_badge'] = 'Pinned';

// 0.18.0 public channels directory
$LANG_VIDEOS['channels'] = 'Channels';
$LANG_VIDEOS['channels_title'] = 'Recommended video channels';
$LANG_VIDEOS['channels_intro'] = 'Discover channels selected for their editorial value and noteworthy videos.';
$LANG_VIDEOS['channels_meta_description'] = 'Discover recommended video channels and their noteworthy videos selected on this site.';
$LANG_VIDEOS['channels_empty'] = 'No recommended channel is available yet.';
$LANG_VIDEOS['channels_unavailable'] = 'The channels directory is temporarily unavailable.';
$LANG_VIDEOS['channels_view_channel'] = 'View videos from this channel';


$LANG_VIDEOS_FAQ = array(
    'catalogue_selection_q' => 'How are the catalogue videos selected?',
    'catalogue_selection_a' => 'The plugin combines the site topic, administrator settings, YouTube availability and local recommendations. Blocked, private and non-embeddable videos are excluded.',
    'catalogue_changes_q' => 'Why can the catalogue change?',
    'catalogue_changes_a' => 'YouTube searches are refreshed through a quota-aware cache. Locally appreciated videos may remain in the permanent pool while unavailable or moderated videos are removed.',
    'catalogue_ratings_q' => 'How do local ratings work?',
    'catalogue_ratings_a' => 'A rating from one to five becomes available after actual playback. A visitor can update a rating, and the previous value is replaced.',
    'catalogue_privacy_q' => 'Is an account required to watch a video?',
    'catalogue_privacy_a' => 'No account is required. When tracking is enabled, anonymous activity uses a pseudonymous identifier and no clear IP address is stored.',
    'video_ranking_score_q' => 'How are videos ranked?',
    'video_ranking_score_a' => 'The ranking uses a weighted rating rather than the raw average, together with qualified views, viewing rate, recent activity and recommendation behaviour.',
    'video_ranking_views_q' => 'What is a qualified view?',
    'video_ranking_views_a' => 'A view is counted only after the configured playback duration or percentage threshold has been reached.',
    'channel_ranking_score_q' => 'How are channels ranked?',
    'channel_ranking_score_a' => 'The local channel score combines ratings, qualified views, appreciated video diversity, recent activity and the performance of its ranked videos.',
    'channel_ranking_diversity_q' => 'Can one channel occupy every recommendation?',
    'channel_ranking_diversity_a' => 'No. A configurable diversity limit restricts the number of videos from the same channel in a recommendation list.',
    'ranking_update_q' => 'When are rankings updated?',
    'ranking_update_a' => 'They are updated after relevant activity and can also be rebuilt by an administrator. Complete recalculations are rate-limited for shared-hosting performance.',
    'video_channel_q' => 'Which channel published this video?',
    'video_channel_a' => 'This video is published by the YouTube channel %channel%.',
    'video_duration_q' => 'How long is this video?',
    'video_duration_a' => 'The duration reported by YouTube is %duration%.',
    'video_publication_q' => 'When was this video published?',
    'video_publication_a' => 'YouTube reports a publication date of %published%.',
    'video_selection_q' => 'Why is this video offered here?',
    'video_selection_a' => 'It matches the site topic and the configured filters, and it remains subject to local moderation, availability and recommendation rules.',
    'video_rating_q' => 'What is its local rating?',
    'video_rating_a' => 'Its current local average is %average% out of 5, based on %count% active rating(s).',
    'unknown_value' => 'not available'
);

$LANG_VIDEOS_TOOLTIPS = array(
    'enabled' => 'Enables the public catalogue and plugin features. Disable it temporarily without uninstalling the plugin or deleting its JSON data.',
    'public_title' => 'Title displayed on the public catalogue and in navigation. The installation default follows the Geeklog language.',
    'language' => 'ISO language code sent to YouTube, for example en or fr. This influences relevance but does not guarantee the language of every video.',
    'region' => 'Two-letter ISO 3166-1 country code, for example US, GB, CA or FR. It is detected from the Geeklog locale when possible.',
    'videos_per_page' => 'Maximum number of videos shown on one catalogue page. Recommended value: 12.',
    'suggestion_count' => 'Number of related or next-video suggestions prepared for a viewing page. Recommended value: 6.',
    'sharing_enabled' => 'Displays sharing links. No social-network JavaScript is loaded and the shared link points to this Geeklog site.',
    'ratings_enabled' => 'Allows visitors to rate a video from 1 to 5 after the configured playback threshold.',
    'view_tracking_enabled' => 'Records a qualified view only after the configured time or percentage threshold. No playback event is written every second.',
    'exclude_short_videos' => 'Enables Shorts exclusion according to the selected mode. The YouTube API exposes no official Shorts flag.',
    'short_filter_mode' => 'Probable Shorts looks for an explicit marker in the title, description or tags and preserves ordinary short videos. Strict mode excludes every video under the threshold.',
    'short_max_duration' => 'Maximum duration treated as short-form content, in seconds. YouTube currently allows Shorts up to 180 seconds. Accepted values: 1 to 600.',
    'youtube_daily_search_limit' => 'Maximum number of costly search.list requests per UTC day. Cached video and channel detail requests are managed separately. Recommended value: 20.',
    'youtube_timeout' => 'Maximum duration of a YouTube API connection in seconds. A short timeout protects shared hosting. Recommended value: 8.',
    'search_cache_ttl' => 'Search result cache lifetime in seconds. 86400 equals 24 hours. Stale results remain available when the API fails.',
    'video_cache_ttl' => 'Video detail cache lifetime in seconds. 86400 equals 24 hours.',
    'channel_cache_ttl' => 'Channel detail cache lifetime in seconds. 604800 equals 7 days.',
    'availability_cache_ttl' => 'Lifetime of a YouTube availability check in seconds. 86400 equals 24 hours. A known unavailable video remains excluded until a later valid API response.',
    'youtube_max_results' => 'Maximum results requested from YouTube for one search, from 1 to 50. Recommended value: 20.',
    'discovery_enabled' => 'Keeps discoveries in a shared JSON reservoir to provide a large catalogue without an API call on every page.',
    'discovery_reservoir_size' => 'Maximum retained references. Recommended value: 500.',
    'catalogue_max_videos' => 'Maximum videos offered in the paginated catalogue. Recommended value: 300.',
    'discovery_seed_searches' => 'Number of 50-result searches during manual seeding, from 1 to 12. Eight searches cost about 800 YouTube units.',
    'discovery_refresh_interval' => 'Minimum seconds between shared automatic refreshes. Recommended value: 86400.',
    'discovery_refresh_percentage' => 'Approximate reservoir share searched during each refresh. Recommended value: 10%.',
    'discovery_recent_percentage' => 'Target share of recently published videos in the presented reservoir. Recommended value: 30%.',
    'discovery_recent_months' => 'A video is recent when published within this number of months. Recommended value: 12.',
    'youtube_safe_search' => 'YouTube SafeSearch level: none, moderate or strict. Recommended public-site value: moderate.',
    'analysis_mode' => 'Keyword source: manual, automatic or mixed. Mixed combines site analysis with administrator keywords and is the recommended default.',
    'manual_keywords' => 'Comma-separated terms describing the site. They reinforce or replace automatically extracted terms according to the analysis mode.',
    'required_keywords' => 'Comma-separated terms that must be present in the controlled YouTube query.',
    'excluded_keywords' => 'Comma-separated words or expressions rejected from queries and candidate results.',
    'additional_stop_words' => 'Comma-separated common words that the automatic analyser must ignore in addition to its built-in stop-word list.',
    'max_keywords' => 'Maximum number of selected terms sent to YouTube. A short query is more stable; recommended value: 8.',
    'title_weight' => 'Relative importance of terms found in titles. Recommended value: 5.',
    'meta_weight' => 'Relative importance of terms found in meta descriptions and keywords. Recommended value: 4.',
    'content_weight' => 'Relative importance of terms found in visible page content. Recommended value: 1.',
    'allowed_channels' => 'Comma-separated YouTube channel IDs. When this allow-list is used, results outside these channels are rejected.',
    'priority_channels' => 'Comma-separated YouTube channel IDs that should receive a recommendation preference without excluding other channels.',
    'blocked_channels' => 'Comma-separated YouTube channel IDs that must never be displayed.',
    'blocked_videos' => 'Comma-separated YouTube video IDs that must never be displayed.',
    'description_mode' => 'Controls the video description: clean selects up to two informative sentences and removes promotional content; hidden displays nothing; raw restores the original truncated description.',
    'youtube_player_mode' => 'standard keeps the accessible YouTube controls. minimal hides the control bar and fullscreen button to reduce exit opportunities, but also removes progress, volume, captions and fullscreen controls. YouTube may still display its title, logo, links and final recommendations.',
    'privacy_enhanced_embed' => 'Uses youtube-nocookie.com for the embedded player. Enabled by default and recommended.',
    'autoplay' => 'Starts playback automatically when allowed by the browser. Disabled by default to protect bandwidth and avoid unexpected playback.',
    'rating_threshold_seconds' => 'Playback time required before rating is enabled, in seconds. For a shorter video, 90% of its duration is used so the threshold remains reachable. Recommended value: 30.',
    'view_threshold_seconds' => 'Playback time used to qualify a local view, in seconds. The first reached time/percentage threshold is used.',
    'view_threshold_percent' => 'Percentage of video duration used to qualify a local view. Recommended value: 25.',
    'ranking_rebuild_interval' => 'Minimum interval between complete ranking rebuilds, in seconds. 3600 equals one hour.',
    'max_same_channel' => 'Maximum videos from the same channel in one recommendation list. Recommended value: 2.',
    'permanent_pool_enabled' => 'Mixes locally appreciated videos into the catalogue so they do not disappear after a new search.',
    'permanent_pool_size' => 'Maximum number of videos retained in the permanent pool. Recommended value: 24.',
    'permanent_pool_percentage' => 'Maximum share of the catalogue reserved for the permanent pool. Recommended value: 25%.',
    'permanent_pool_auto' => 'Automatically admits videos reaching the configured rating count and weighted rating.',
    'permanent_pool_min_ratings' => 'Minimum local rating count before automatic admission. Recommended value: 3.',
    'permanent_pool_min_weighted_rating' => 'Minimum Bayesian weighted rating out of 5. One excellent rating is therefore insufficient. Recommended value: 4.0.',
    'permanent_pool_keep_below_threshold' => 'Keeps an admitted video if its score later drops. Maximum size, blocks and availability still take precedence.',
    'public_rankings_enabled' => 'Displays a rankings page accessible to all visitors and adds it to the Videos navigation.',
    'public_video_ranking_enabled' => 'Displays the simplified local video ranking on the public rankings page.',
    'public_channel_ranking_enabled' => 'Displays the simplified local channel ranking on the public rankings page.',
    'public_ranking_limit' => 'Maximum number of videos and channels displayed in each public ranking. Recommended value: 10.',
    'account_history_enabled' => 'Associates watched and rated videos with a registered account through a pseudonymous HMAC identifier.',
    'account_recommendations_enabled' => 'Allows registered-account history and ratings to influence future recommendations.',
    'anonymous_tracking_enabled' => 'Uses a random pseudonymous visitor cookie for qualified views and ratings. No clear IP address is stored.',
    'allow_anonymous_merge' => 'Allows eligible anonymous history to be associated with a registered account after sign-in.',
    'allow_user_export' => 'Allows registered users to obtain their stored plugin data in JSON format when the export interface is available.',
    'allow_user_deletion' => 'Allows registered users to explicitly delete their plugin history when the deletion interface is available.',
    'account_retention_days' => 'Must remain 0: registered account history is retained until the user deletes it.',
    'automatic_account_purge' => 'Must remain disabled. Account history is never purged automatically.',
    'anonymous_retention_days' => 'Retention period for anonymous visitor identifiers and history, in days. Recommended value: 90.',
    'privacy_notice' => 'Short privacy information displayed to visitors. Explain the pseudonymous cookie, viewing history and ratings.',
    'block_enabled' => 'Creates or enables the optional Geeklog Videos block. Keep disabled until its placement has been checked with the active theme.',
    'block_isleft' => 'Places the optional block in the left column when enabled; otherwise Geeklog places it in the right column.',
    'block_order' => 'Geeklog display order of the block within its column. Lower values are displayed first.',
    'block_mode' => 'Select the content displayed by the optional block, a random video selection, or a random choice among all six content modes. No mode makes an additional YouTube API call.',
    'block_item_count' => 'Number of items displayed in the optional block, from 1 to 10. Recommended value: 3.',
    'seo_enabled' => 'Enables SEO metadata. Private and unavailable pages always remain noindex.',
    'seo_catalogue_index' => 'Allows non-empty catalogue pages to be indexed.',
    'seo_rankings_index' => 'Allows non-empty public ranking tabs to be indexed.',
    'seo_structured_data' => 'Adds schema.org VideoObject JSON-LD to valid watch pages using cached YouTube data.',
    'seo_social_metadata' => 'Adds Open Graph and Twitter Card metadata without loading social scripts.',
    'seo_description_fallback' => 'Optional generic meta description. Leave empty for a factual page-specific fallback.',
    'faq_catalogue_enabled' => 'Displays a useful FAQ below the first non-empty catalogue page.',
    'faq_video_enabled' => 'Displays dynamic factual information below each valid watch page.',
    'faq_rankings_enabled' => 'Displays an explanatory FAQ tailored to the active public ranking tab.',
    'faq_structured_data' => 'Experimental: adds FAQPage JSON-LD matching the visible FAQ. Disabled by default because rich FAQ results are not generally available for this type of site.',
    'technical_log_days' => 'Retention duration of limited technical logs, in days. Logs exclude the YouTube API key and unnecessary personal data.'
);

$LANG_configsections['videos'] = array(
    'label' => 'Videos',
    'title' => 'Videos Plugin Configuration'
);

$LANG_configsubgroups['videos'] = array(
    'sg_main' => 'Main Settings'
);

$LANG_tab['videos'] = array(
    'tab_general' => 'General',
    'tab_youtube' => 'YouTube API',
    'tab_analysis' => 'Site Analysis',
    'tab_sources' => 'Videos and Channels',
    'tab_ranking' => 'Ratings and Recommendations',
    'tab_privacy' => 'Privacy',
    'tab_block' => 'Block',
    'tab_seo' => 'SEO',
    'tab_maintenance' => 'Maintenance'
);

$LANG_fs['videos'] = array(
    'fs_general' => 'General Settings',
    'fs_youtube' => 'YouTube Data API v3',
    'fs_analysis' => 'Keyword Analysis',
    'fs_sources' => 'Videos and Channels',
    'fs_ranking' => 'Ratings and Recommendations',
    'fs_privacy' => 'Privacy and Retention',
    'fs_block' => 'Geeklog Block',
    'fs_seo' => 'Public Page SEO',
    'fs_maintenance' => 'Maintenance'
);

$LANG_confignames['videos'] = array(
    'enabled' => 'Plugin Enabled',
    'public_title' => 'Public Title',
    'language' => 'Language',
    'region' => 'Region',
    'videos_per_page' => 'Videos per Page',
    'suggestion_count' => 'Number of Suggestions',
    'sharing_enabled' => 'Enable Sharing',
    'ratings_enabled' => 'Enable Ratings',
    'view_tracking_enabled' => 'Enable View Tracking',
    'youtube_daily_search_limit' => 'Daily Search Limit',
    'youtube_timeout' => 'Connection Timeout',
    'search_cache_ttl' => 'Search Cache Duration',
    'video_cache_ttl' => 'Video Cache Duration',
    'channel_cache_ttl' => 'Channel Cache Duration',
    'availability_cache_ttl' => 'Availability Check Duration',
    'youtube_max_results' => 'Maximum Search Results',
    'discovery_enabled' => 'Enable Discovery Reservoir',
    'discovery_reservoir_size' => 'Reservoir Capacity',
    'catalogue_max_videos' => 'Maximum Catalogue Size',
    'discovery_seed_searches' => 'Searches per Seed',
    'discovery_refresh_interval' => 'Refresh Interval',
    'discovery_refresh_percentage' => 'Renewed Percentage',
    'discovery_recent_percentage' => 'Recent Video Percentage',
    'discovery_recent_months' => 'Recent Video Maximum Age',
    'youtube_safe_search' => 'Safe Search Level',
    'analysis_mode' => 'Analysis Mode',
    'manual_keywords' => 'Manual Keywords',
    'required_keywords' => 'Required Keywords',
    'excluded_keywords' => 'Excluded Keywords',
    'additional_stop_words' => 'Additional Stop Words',
    'max_keywords' => 'Maximum Keywords',
    'title_weight' => 'Title Weight',
    'meta_weight' => 'Meta Weight',
    'content_weight' => 'Content Weight',
    'allowed_channels' => 'Allowed Channels',
    'priority_channels' => 'Priority Channels',
    'blocked_channels' => 'Blocked Channels',
    'blocked_videos' => 'Blocked Videos',
    'exclude_short_videos' => 'Exclude short-form videos (Shorts)',
    'short_filter_mode' => 'Shorts detection method',
    'short_max_duration' => 'Short-form threshold in seconds',
    'description_mode' => 'Video Description',
    'youtube_player_mode' => 'YouTube Player Mode',
    'privacy_enhanced_embed' => 'Privacy-enhanced Embedding',
    'autoplay' => 'Autoplay',
    'rating_threshold_seconds' => 'Rating Threshold in Seconds',
    'view_threshold_seconds' => 'View Threshold in Seconds',
    'view_threshold_percent' => 'View Threshold Percentage',
    'ranking_rebuild_interval' => 'Ranking Rebuild Interval',
    'max_same_channel' => 'Maximum Videos from Same Channel',
    'permanent_pool_enabled' => 'Enable Permanent Pool',
    'permanent_pool_size' => 'Maximum Pool Size',
    'permanent_pool_percentage' => 'Catalogue Share Percentage',
    'permanent_pool_auto' => 'Automatic Admission',
    'permanent_pool_min_ratings' => 'Minimum Rating Count',
    'permanent_pool_min_weighted_rating' => 'Minimum Weighted Rating',
    'permanent_pool_keep_below_threshold' => 'Keep After Score Drop',
    'public_rankings_enabled' => 'Enable Public Rankings Page',
    'public_video_ranking_enabled' => 'Display Video Ranking',
    'public_channel_ranking_enabled' => 'Display Channel Ranking',
    'public_ranking_limit' => 'Public Ranking Size',
    'account_history_enabled' => 'Registered Account History',
    'account_recommendations_enabled' => 'Personal Recommendations',
    'anonymous_tracking_enabled' => 'Anonymous Tracking',
    'allow_anonymous_merge' => 'Allow Anonymous History Merge',
    'allow_user_export' => 'Allow User Export',
    'allow_user_deletion' => 'Allow User Deletion',
    'account_retention_days' => 'Registered Account Retention',
    'automatic_account_purge' => 'Automatic Account Purge',
    'anonymous_retention_days' => 'Anonymous Retention in Days',
    'privacy_notice' => 'Privacy Notice',
    'block_enabled' => 'Enable Block',
    'block_isleft' => 'Display Block on Left',
    'block_order' => 'Block Order',
    'block_mode' => 'Block Mode',
    'block_item_count' => 'Number of Block Items',
    'seo_enabled' => 'Enable SEO Metadata',
    'seo_catalogue_index' => 'Index the Catalogue',
    'seo_rankings_index' => 'Index Public Rankings',
    'seo_structured_data' => 'VideoObject Structured Data',
    'seo_social_metadata' => 'Open Graph and Twitter Metadata',
    'seo_description_fallback' => 'Fallback Meta Description',
    'faq_catalogue_enabled' => 'Catalogue FAQ',
    'faq_video_enabled' => 'Video Information FAQ',
    'faq_rankings_enabled' => 'Rankings FAQ',
    'faq_structured_data' => 'Experimental FAQPage Data',
    'technical_log_days' => 'Technical Log Retention in Days'
);

$LANG_configselects['videos'] = array(
    0 => array('True' => 1, 'False' => 0),
    1 => array(
        'Clean informative excerpt' => 'clean',
        'Hidden' => 'hidden',
        'Raw truncated description' => 'raw'
    ),
    2 => array(
        'Standard controls' => 'standard',
        'Minimal player' => 'minimal'
    ),
    3 => array(
        'Recommended (combined local score)' => 'recommended',
        'Best weighted ratings (Bayesian)' => 'top_rated',
        'Most watched (qualified views)' => 'most_watched',
        'Recently watched on this site' => 'recent_activity',
        'Random video selection' => 'random',
        'Best channels (local score)' => 'best_channels',
        'Random choice among all 6 modes' => 'random_mode'
    ),
    4 => array(
        'Probable Shorts (recommended)' => 'probable',
        'Every video under threshold (strict)' => 'strict'
    )
);

// Videos 0.19.0 semantic administration strings
$LANG_VIDEOS['admin_explicit_editorial_exclusions'] = 'Explicit editorial exclusions';
$LANG_VIDEOS['admin_youtube_data_api_key_has_been_saved'] = 'The YouTube Data API key has been saved.';
$LANG_VIDEOS['admin_videos_list_details'] = 'videos.list details';
$LANG_VIDEOS['admin_video_seo'] = 'Video SEO: ';
$LANG_VIDEOS['admin_editorial_decision_saved'] = 'Editorial decision saved.';
$LANG_VIDEOS['admin_all_statistics'] = 'All statistics';
$LANG_VIDEOS['admin_local_video_corpus_available_native_search'] = 'The local video corpus is available in native search.';
$LANG_VIDEOS['admin_public_pages'] = 'Public pages:';
$LANG_VIDEOS['admin_availability'] = 'Availability';
$LANG_VIDEOS['admin_partial_cleanup'] = 'Partial cleanup: ';
$LANG_VIDEOS['admin_send_existing_pages_indexnow'] = 'Send existing pages to IndexNow';
$LANG_VIDEOS['admin_pinned'] = 'Pinned';
$LANG_VIDEOS['admin_video_curation'] = 'Video curation';
$LANG_VIDEOS['admin_channel_information'] = 'Channel information';
$LANG_VIDEOS['admin_last_success'] = 'Last success';
$LANG_VIDEOS['admin_priority_channels'] = 'Priority channels';
$LANG_VIDEOS['admin_last_api_error'] = 'Last API error';
$LANG_VIDEOS['admin_videos_retained_permanently'] = 'Videos retained permanently';
$LANG_VIDEOS['admin_video_added_permanent_catalogue'] = 'Video added to the permanent catalogue.';
$LANG_VIDEOS['admin_at_glance'] = 'At a glance';
$LANG_VIDEOS['admin_iteminfo_interoperability'] = 'ItemInfo interoperability';
$LANG_VIDEOS['admin_catalogue_search'] = 'Catalogue search';
$LANG_VIDEOS['admin_geeklog_search'] = 'Geeklog search';
$LANG_VIDEOS['admin_add_permanent_catalogue'] = 'Add to permanent catalogue';
$LANG_VIDEOS['admin_geeklog_integration'] = 'Geeklog integration';
$LANG_VIDEOS['admin_quota_suspended'] = 'Quota suspended';
$LANG_VIDEOS['admin_video_s_added_reservoir'] = ' video(s) added to the reservoir.';
$LANG_VIDEOS['admin_youtube_quota_suspended'] = 'YouTube quota is suspended (';
$LANG_VIDEOS['admin_local_search_limit'] = 'Local search limit';
$LANG_VIDEOS['admin_last_search'] = 'Last search';
$LANG_VIDEOS['admin_https_youtu_be'] = ' or https://youtu.be/…';
$LANG_VIDEOS['admin_video'] = 'Video';
$LANG_VIDEOS['admin_youtube_id_url'] = 'YouTube ID or URL';
$LANG_VIDEOS['admin_public_corpus_used_by_geeklog_catalogue'] = 'Public corpus used by Geeklog and the catalogue';
$LANG_VIDEOS['admin_permanent_catalogue'] = 'Permanent catalogue';
$LANG_VIDEOS['admin_index_existing_pages'] = 'Index existing pages';
$LANG_VIDEOS['admin_test_search'] = 'Test search';
$LANG_VIDEOS['admin_size'] = 'Size';
$LANG_VIDEOS['admin_open_repair_tools'] = 'Open repair tools';
$LANG_VIDEOS['admin_ranking_rebuild_failed'] = 'Ranking rebuild failed.';
$LANG_VIDEOS['admin_seed_reservoir'] = 'Seed reservoir';
$LANG_VIDEOS['admin_last_youtube_error'] = 'Last YouTube error: ';
$LANG_VIDEOS['admin_video_catalogue_status_quick_actions_geeklog_integrati'] = 'Video catalogue status, quick actions and Geeklog integrations.';
$LANG_VIDEOS['admin_cache_entrie_s_deleted'] = ' cache entrie(s) deleted.';
$LANG_VIDEOS['admin_pinned_videos'] = 'Pinned videos';
$LANG_VIDEOS['admin_last_rejected_call'] = 'Last rejected call:';
$LANG_VIDEOS['admin_availability_checks'] = 'Availability checks';
$LANG_VIDEOS['admin_permanent'] = 'Permanent';
$LANG_VIDEOS['admin_last_valid_api_response'] = 'Last valid API response';
$LANG_VIDEOS['admin_videos_with_local_signals'] = 'Videos with local signals';
$LANG_VIDEOS['admin_local_youtube_search_limit_has_been_reached'] = 'The local YouTube search limit has been reached (';
$LANG_VIDEOS['admin_youtube_data_api_key_required_search_new'] = 'A YouTube Data API key is required to search for new videos and retrieve data for an uncached video. Cached videos remain available without a new API call.';
$LANG_VIDEOS['admin_integrations'] = 'Integrations';
$LANG_VIDEOS['admin_videos_excluded_from_pool'] = 'Videos excluded from the pool';
$LANG_VIDEOS['admin_rebuild_rankings'] = 'Rebuild rankings';
$LANG_VIDEOS['admin_public_editorial_content'] = 'Public and editorial content';
$LANG_VIDEOS['admin_search_results'] = 'Search results';
$LANG_VIDEOS['admin_active'] = 'Active';
$LANG_VIDEOS['admin_never'] = 'Never';
$LANG_VIDEOS['admin_test_search_8cfd'] = 'Test search';
$LANG_VIDEOS['admin_videos_plugin_storage_unavailable_use_repair_tools'] = 'Videos plugin storage is unavailable. Use the repair tools.';
$LANG_VIDEOS['admin_videos_reservoir'] = 'Videos in reservoir';
$LANG_VIDEOS['admin_catalogue'] = 'Catalogue';
$LANG_VIDEOS['admin_videos_public_pages'] = 'Videos public pages';
$LANG_VIDEOS['admin_seed_query'] = 'Seed query';
$LANG_VIDEOS['admin_no_video_available_seo_diagnostics'] = 'No video is available for the SEO diagnostics.';
$LANG_VIDEOS['admin_video_calls'] = 'Video calls';
$LANG_VIDEOS['admin_api_key_invalid'] = 'The API key is invalid.';
$LANG_VIDEOS['admin_technical_diagnostics'] = 'Technical diagnostics';
$LANG_VIDEOS['admin_compatible'] = 'Compatible';
$LANG_VIDEOS['admin_youtube_api_activity'] = 'YouTube API activity';
$LANG_VIDEOS['admin_videos_url_s_sent_indexnow_one_batch'] = ' Videos URL(s) sent to IndexNow in one batch.';
$LANG_VIDEOS['admin_searches_today'] = 'Searches today';
$LANG_VIDEOS['admin_video_currently_blocked_by_moderation'] = 'This video is currently blocked by moderation.';
$LANG_VIDEOS['admin_unpin'] = 'Unpin';
$LANG_VIDEOS['admin_deleted'] = ' deleted, ';
$LANG_VIDEOS['admin_exclude_from_future_selections'] = 'Exclude from future selections';
$LANG_VIDEOS['admin_video_information'] = 'Video information';
$LANG_VIDEOS['admin_ranked_videos'] = 'Ranked videos';
$LANG_VIDEOS['admin_limit_reached'] = 'Limit reached (';
$LANG_VIDEOS['admin_status'] = 'Status:';
$LANG_VIDEOS['admin_add_video'] = 'Add a video';
$LANG_VIDEOS['admin_configuration'] = 'Configuration';
$LANG_VIDEOS['admin_video_unavailable_private_not_embeddable_rejected_by'] = 'The video is unavailable, private, not embeddable, or rejected by plugin policy.';
$LANG_VIDEOS['admin_replace_api_key'] = 'Replace API key';
$LANG_VIDEOS['admin_last_authorized_search_list_reservation'] = 'Last authorized search.list reservation';
$LANG_VIDEOS['admin_test_search_failed'] = 'The test search failed.';
$LANG_VIDEOS['admin_unavailable'] = 'Unavailable';
$LANG_VIDEOS['admin_search_list_calls'] = 'search.list calls';
$LANG_VIDEOS['admin_strong_selections_including_legacy_0_17_pins'] = 'Strong selections, including legacy 0.17 pins';
$LANG_VIDEOS['admin_searches'] = 'Searches';
$LANG_VIDEOS['admin_syndication'] = 'Syndication';
$LANG_VIDEOS['admin_test_query_invalid'] = 'The test query is invalid.';
$LANG_VIDEOS['admin_catch_up_process_inventories_public_pages_sends'] = 'The catch-up process inventories public pages and sends them to IndexNow in batch mode.';
$LANG_VIDEOS['admin_channel_calls'] = 'Channel calls';
$LANG_VIDEOS['admin_developer_information'] = 'Developer information';
$LANG_VIDEOS['admin_invalid_youtube_id_url'] = 'Invalid YouTube ID or URL.';
$LANG_VIDEOS['admin_channels'] = 'Channels';
$LANG_VIDEOS['admin_rebuild_permanent_catalogue'] = 'Rebuild permanent catalogue';
$LANG_VIDEOS['admin_failure_s'] = ' failure(s).';
$LANG_VIDEOS['admin_persistent_public_content_exposed_through_geeklog_item'] = 'Persistent public content is exposed through the Geeklog ItemInfo API.';
$LANG_VIDEOS['admin_maintenance'] = 'Maintenance';
$LANG_VIDEOS['admin_no_public_videos_url_submit'] = 'No public Videos URL to submit.';
$LANG_VIDEOS['admin_needs_review'] = 'Needs review';
$LANG_VIDEOS['admin_channel_ranking'] = 'Channel ranking';
$LANG_VIDEOS['admin_pin'] = 'Pin';
$LANG_VIDEOS['admin_add_api_key'] = 'Add API key';
$LANG_VIDEOS['admin_allow_again'] = 'Allow again';
$LANG_VIDEOS['admin_api_key_missing'] = 'API key missing.';
$LANG_VIDEOS['admin_none'] = 'None';
$LANG_VIDEOS['admin_test_video'] = 'Test video';
$LANG_VIDEOS['admin_replace_key'] = 'Replace key';
$LANG_VIDEOS['admin_suspension_after_quota_error_reported_by_youtube'] = 'Suspension after a quota error reported by YouTube';
$LANG_VIDEOS['admin_active_d2f1'] = 'Active';
$LANG_VIDEOS['admin_view_catalogue'] = 'View catalogue';
$LANG_VIDEOS['admin_videos_plugin_storage_unavailable'] = 'Videos plugin storage is unavailable.';
$LANG_VIDEOS['admin_searchable_videos'] = 'Searchable videos';
$LANG_VIDEOS['admin_video_seo_c7b7'] = 'Video SEO';
$LANG_VIDEOS['admin_complete'] = 'To complete';
$LANG_VIDEOS['admin_global_ranking'] = 'Global ranking';
$LANG_VIDEOS['admin_active_editorial_decisions'] = 'Active editorial decisions';
$LANG_VIDEOS['admin_all'] = 'All';
$LANG_VIDEOS['admin_seed_query_invalid'] = 'The seed query is invalid.';
$LANG_VIDEOS['admin_ranked_channels'] = 'Ranked channels';
$LANG_VIDEOS['admin_available'] = 'Available';
$LANG_VIDEOS['admin_local_discovery_corpus'] = 'Local discovery corpus';
$LANG_VIDEOS['admin_reservoir_seeding_failed'] = 'Reservoir seeding failed.';
$LANG_VIDEOS['admin_indexnow_plugin_unavailable_no_fake_content_creation'] = 'The IndexNow plugin is unavailable. No fake content creation event was emitted.';
$LANG_VIDEOS['admin_channels_list_details'] = 'channels.list details';
$LANG_VIDEOS['admin_repair_tools'] = 'Repair tools';
$LANG_VIDEOS['admin_rankings_rebuilt'] = 'Rankings rebuilt: ';
$LANG_VIDEOS['admin_permanent_catalogue_rebuild_failed'] = 'Permanent catalogue rebuild failed.';
$LANG_VIDEOS['admin_api_key_configured'] = 'API key configured.';
$LANG_VIDEOS['admin_no_retained_video'] = 'No retained video.';
$LANG_VIDEOS['admin_status_db27'] = 'Status';
$LANG_VIDEOS['admin_xml_sitemap'] = 'XML Sitemap';
$LANG_VIDEOS['admin_channels_from_local_ranking'] = 'Channels from the local ranking';
$LANG_VIDEOS['admin_unable_add_video_permanent_catalogue'] = 'Unable to add the video to the permanent catalogue.';
$LANG_VIDEOS['admin_clear_cache'] = 'Clear cache';
$LANG_VIDEOS['admin_remove_from_selection'] = 'Remove from selection';
$LANG_VIDEOS['admin_video_ranking'] = 'Video ranking';
$LANG_VIDEOS['admin_ranked_video_s'] = ' ranked video(s).';
$LANG_VIDEOS['admin_today'] = ' today).';
$LANG_VIDEOS['admin_rss_atom_feeds_through_geeklog_native_syndication'] = 'RSS/Atom feeds through Geeklog native syndication.';
$LANG_VIDEOS['admin_security_token_has_expired_please_try_again'] = 'The security token has expired. Please try again.';
$LANG_VIDEOS['admin_add_video_directly_by_its_youtube_id'] = 'Add a video directly by its YouTube ID or URL. It is fetched, cached, added to the permanent catalogue, then signalled through Geeklog events.';
$LANG_VIDEOS['admin_save_key'] = 'Save key';
$LANG_VIDEOS['admin_videos'] = 'Videos';
$LANG_VIDEOS['admin_see_statistics_youtube_api_activity_diagnostics'] = 'See Statistics > YouTube API activity for diagnostics.';
$LANG_VIDEOS['admin_excluded_from_pool'] = 'Excluded from pool';
$LANG_VIDEOS['admin_active_1a31'] = 'Active';
$LANG_VIDEOS['admin_geeklog_statistics'] = 'Geeklog statistics';
$LANG_VIDEOS['admin_valid_video_s_found'] = ' valid video(s) found.';
$LANG_VIDEOS['admin_entries'] = 'Entries';
$LANG_VIDEOS['admin_indexnow_batch_could_not_be_sent'] = 'The IndexNow batch could not be sent.';
$LANG_VIDEOS['admin_unable_save_decision'] = 'Unable to save this decision.';
$LANG_VIDEOS['admin_permanent_catalogue_has_been_rebuilt'] = 'The permanent catalogue has been rebuilt.';
$LANG_VIDEOS['admin_latest_entry'] = 'Latest entry';
$LANG_VIDEOS['admin_reservoir'] = 'Reservoir';
$LANG_VIDEOS['admin_statistics'] = 'Statistics';
$LANG_VIDEOS['admin_daily_limit_configured_videos'] = 'Daily limit configured in Videos';
// End Videos 0.19.0 semantic administration strings
