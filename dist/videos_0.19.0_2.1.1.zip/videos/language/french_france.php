<?php

$LANG_VIDEOS = array(
    'plugin_name' => 'Vidéos',
    'admin_title' => 'Administration des vidéos',
    'public_title' => 'Vidéos',
    'my_videos' => 'Mes vidéos',
    'catalogue' => 'Catalogue vidéo',
    'rankings' => 'Classements',
    'video_navigation' => 'Navigation des vidéos',
    'rating_saved' => 'Votre note a été enregistrée.',
    'rating_error' => 'La note n’a pas pu être enregistrée.',
    'rating_delete' => 'Supprimer ma note',
    'rating_delete_confirm' => 'Supprimer votre note pour cette vidéo ? L’historique de lecture sera conservé.',
    'rating_deleted' => 'Votre note a été supprimée.',
    'rating_delete_error' => 'Votre note n’a pas pu être supprimée.',
    'history_rating_deleted' => 'Votre note a été supprimée. La vidéo reste dans votre historique de lecture.',
    'history_rating_delete_failed' => 'Votre note n’a pas pu être supprimée. Veuillez réessayer.',
    'copy_link' => 'Copier le lien',
    'native_share' => 'Partager',
    'link_copied' => 'Lien copié.',
    'rating_locked' => 'Commencez la lecture pour activer la notation.',
    'rating_waiting' => 'La notation sera activée après le seuil de visionnage.',
    'playback_error' => 'Le suivi de la lecture est indisponible.',
    'rating_countdown' => 'Notation disponible dans %d secondes.',
    'all_videos' => 'Toutes',
    'watched_videos' => 'Regardées',
    'rated_videos' => 'Notées',
    'watch_again' => 'Regarder à nouveau',
    'your_rating' => 'Votre note',
    'local_average' => 'Moyenne locale',
    'personal_views' => 'Lectures personnelles',
    'watched_on' => 'Regardée le',
    'no_personal_videos' => 'Aucune vidéo ne correspond à ce filtre.',
    'manage_personal_data' => 'Gérer mes données vidéo',
    'manage_personal_data_help' => 'Téléchargez les données vidéo conservées ou supprimez définitivement votre historique personnel et vos notes.',
    'export_personal_data' => 'Télécharger mes données (JSON)',
    'delete_personal_data' => 'Supprimer mes données vidéo',
    'delete_personal_data_checkbox' => 'Je comprends que mon historique vidéo personnel et mes notes seront définitivement supprimés.',
    'delete_personal_data_confirm' => 'Supprimer définitivement votre historique vidéo personnel et vos notes ? Cette action est irréversible.',
    'history_deleted' => 'Votre historique vidéo personnel et vos notes ont été supprimés.',
    'history_delete_failed' => 'Certaines données vidéo personnelles n’ont pas pu être supprimées. Réessayez ou contactez l’administrateur du site.',
    'history_delete_denied' => 'La suppression des données personnelles est désactivée par l’administrateur.',
    'history_delete_confirm' => 'Vous devez confirmer la suppression définitive.',
    'history_export_failed' => 'Vos données vidéo n’ont pas pu être exportées.',
    'history_export_denied' => 'L’export des données personnelles est désactivé par l’administrateur.',
    'history_csrf' => 'Le jeton de sécurité a expiré. Veuillez recommencer.',
    'cache_maintenance' => 'Maintenance du cache YouTube',
    'cache_scope' => 'Cache à vider',
    'cache_search' => 'Résultats de recherche',
    'cache_videos' => 'Informations des vidéos',
    'cache_channels' => 'Informations des chaînes',
    'cache_availability' => 'Vérifications de disponibilité',
    'cache_all' => 'Tous les caches YouTube',
    'cache_clear' => 'Vider le cache sélectionné',
    'cache_confirm' => 'Vider le cache YouTube sélectionné ? Les vues, notes et historiques seront conservés.',
    'cache_cleared' => '%d entrées de cache ont été supprimées.',
    'cache_clear_partial' => '%d entrées ont été supprimées, mais %d fichiers n’ont pas pu être retirés.',
    'cache_clear_denied' => 'Vous ne disposez pas du droit nécessaire pour vider le cache.',
    'cache_entries' => 'Entrées',
    'cache_size' => 'Volume',
    'cache_latest' => 'Entrée la plus récente',
    'quota_status' => 'Activité de l’API YouTube aujourd’hui',
    'quota_search_calls' => 'Appels de recherche',
    'quota_video_calls' => 'Appels de détails vidéo',
    'quota_channel_calls' => 'Appels de détails chaîne',
    'quota_last_search' => 'Dernière recherche',
    'quota_last_success' => 'Dernier succès API',
    'quota_last_error' => 'Dernière erreur API',
    'never' => 'Jamais',
    'already_watched' => 'Déjà regardée',
    'catalogue_page' => 'Page %d sur %d',
    'previous_page' => 'Précédente',
    'next_page' => 'Suivante',
    'video_duration' => 'Durée',
    'no_more_videos' => 'Aucune autre vidéo n’est disponible sur cette page.',
    'global_ranking' => 'Classement global des vidéos',
    'ranking_rebuild' => 'Reconstruire les classements vidéos et chaînes',
    'ranking_confirm' => 'Reconstruire les classements vidéos et chaînes à partir des statistiques JSON existantes ?',
    'ranking_rebuilt' => 'Les classements ont été reconstruits avec %d vidéos et leurs chaînes.',
    'ranking_rebuild_failed' => 'Les classements vidéos et chaînes n’ont pas pu être reconstruits.',
    'ranking_score' => 'Score',
    'ranking_views' => 'Vues',
    'ranking_watch_rate' => 'Taux au seuil de qualification',
    'recommendation_accepted' => 'Choisie comme suivante',
    'recommendation_skipped' => 'Refusée',
    'ranking_no_data' => 'Aucune vidéo classée n’est encore disponible.',
    'channel_ranking' => 'Classement local des chaînes',
    'channel_ranking_no_data' => 'Aucune chaîne classée n’est encore disponible.',
    'channel' => 'Chaîne',
    'channel_videos' => 'Vidéos distinctes',
    'public_rankings_title' => 'Classements des vidéos et des chaînes',
    'public_rankings_intro' => 'Découvrez les vidéos et les chaînes les plus appréciées par les visiteurs de ce site.',
    'public_rankings_disabled' => 'La page publique des classements est désactivée.',
    'public_rankings_unavailable' => 'Les classements sont temporairement indisponibles.',
    'public_rankings_empty' => 'Aucun classement public n’est actuellement activé.',
    'top_videos' => 'Meilleures vidéos',
    'top_channels' => 'Meilleures chaînes',
    'ranking_tabs_navigation' => 'Choisir un classement',
    'next_video' => 'Vidéo suivante',
    'next_video_help' => 'Suggestion fondée sur la thématique actuelle et les classements locaux.',
    'another_suggestion' => 'Autre suggestion',
    'watch_next' => 'Regarder cette vidéo',
    'no_next_video' => 'Aucune vidéo suivante adaptée n’est actuellement disponible.',
    'block_title' => 'Vidéos recommandées',
    'block_title_recommended' => 'Vidéos recommandées',
    'block_title_top_rated' => 'Meilleures notes pondérées',
    'block_title_most_watched' => 'Vidéos les plus regardées',
    'block_title_recent_activity' => 'Vidéos regardées récemment',
    'block_title_best_channels' => 'Meilleures chaînes locales',
    'block_metric_recommended' => 'Score local combiné : %s',
    'block_metric_weighted_rating' => 'Note pondérée : %s/5 (%d notes)',
    'block_metric_views' => '%d vues qualifiées',
    'block_metric_last_viewed' => 'Dernière lecture locale : %s',
    'block_metric_channel' => '%s/5 · %d vidéos · %d vues',
    'block_mode_recommended' => 'Recommandées pour ce site',
    'block_mode_top_rated' => 'Meilleures notes locales pondérées',
    'block_mode_most_watched' => 'Plus grand nombre de vues qualifiées',
    'block_mode_recent_activity' => 'Regardées récemment sur ce site',
    'block_mode_random' => 'Sélection aléatoire parmi les vidéos locales',
    'block_mode_best_channels' => 'Chaînes les mieux classées localement',
    'view_video_catalogue' => 'Voir le catalogue vidéo',
    'view_channel_ranking' => 'Voir le classement des chaînes',
    'access_denied' => 'Vous ne disposez pas des droits nécessaires pour accéder à cette page.',
    'development_version' => 'Cette version de développement ne doit pas encore être utilisée publiquement.',
    'moderation_title' => 'Modération des vidéos et des chaînes',
    'moderation_storage_error' => 'Le stockage de la modération ne peut pas être initialisé.',
    'moderate_video' => 'Modérer une vidéo',
    'moderate_channel' => 'Gérer une chaîne',
    'moderated_videos' => 'Décisions actives sur les vidéos',
    'moderated_channels' => 'Décisions actives sur les chaînes',
    'video_id' => 'Identifiant de vidéo YouTube',
    'channel_id' => 'Identifiant de chaîne YouTube',
    'moderation_state' => 'État',
    'moderation_reason' => 'Motif interne',
    'moderation_save' => 'Enregistrer la décision',
    'moderation_saved' => 'La décision de modération a été enregistrée.',
    'moderation_invalid' => 'L’identifiant ou l’état de modération est invalide.',
    'moderation_state_neutral' => 'Neutre (retirer la décision)',
    'moderation_state_allowed' => 'Autorisée',
    'moderation_state_priority' => 'Prioritaire',
    'moderation_state_blocked' => 'Bloquée',
    'moderation_state_disabled' => 'Désactivée',
    'moderation_item' => 'Élément',
    'moderation_date' => 'Date',
    'moderation_action' => 'Action',
    'moderation_remove' => 'Revenir à neutre',
    'moderation_neutral_confirm' => 'Retirer cette décision de modération ?',
    'moderation_no_records' => 'Aucune décision de modération active.',
    'moderation_quick_actions' => 'Actions de modération',
    'moderation_block_video' => 'Bloquer la vidéo',
    'moderation_block_channel' => 'Bloquer la chaîne',
    'moderation_block_video_confirm' => 'Bloquer cette vidéo et la retirer immédiatement du plugin ?',
    'moderation_block_channel_confirm' => 'Bloquer cette chaîne et retirer toutes ses vidéos du plugin ?',
    'moderation_quick_reason_video' => 'Blocage depuis la page de lecture',
    'moderation_quick_reason_channel' => 'Blocage depuis la page de lecture',
    'moderation_quick_failed' => 'La décision de modération n’a pas pu être enregistrée.',
    'cancel' => 'Annuler',
    'known_channel' => 'Chaîne connue du plugin',
    'choose_known_channel' => 'Sélectionner une chaîne par son nom',
    'known_channel_help' => 'Les chaînes sont issues des recherches YouTube déjà effectuées par le plugin.',
    'known_channel_empty' => 'Aucune chaîne n’est encore connue. Lancez une recherche d’amorçage puis revenez sur cette page.',
    'manual_channel_entry' => 'Saisie avancée d’un identifiant UC…',
    'permanent_pool_badge' => 'Sélection permanente',
    'permanent_pool_title' => 'Fonds permanent du catalogue',
    'permanent_pool_count' => 'Vidéos conservées',
    'permanent_pool_excluded_count' => 'Vidéos exclues du fonds',
    'permanent_pool_last_rebuild' => 'Dernière reconstruction',
    'permanent_pool_video_id' => 'Identifiant de vidéo à épingler',
    'permanent_pool_pin' => 'Épingler',
    'permanent_pool_rebuild' => 'Reconstruire le fonds',
    'permanent_pool_remove' => 'Retirer',
    'permanent_pool_exclude' => 'Retirer et exclure',
    'permanent_pool_allow' => 'Autoriser de nouveau',
    'permanent_pool_excluded_list' => 'Vidéos exclues manuellement',
    'permanent_pool_source' => 'Origine',
    'permanent_pool_source_manual' => 'Épinglage manuel',
    'permanent_pool_source_automatic' => 'Admission automatique',
    'permanent_pool_action_saved' => 'Le fonds permanent a été mis à jour.',
    'permanent_pool_action_failed' => 'Le fonds permanent n’a pas pu être mis à jour.',
    'permanent_pool_confirm' => 'Confirmer cette modification du fonds permanent ?',
    'discovery_seed_query' => 'Thématique du réservoir',
    'discovery_seed_button' => 'Amorcer ou enrichir le réservoir',
    'discovery_seed_confirm' => 'L’amorçage peut consommer plusieurs centaines d’unités de quota YouTube. Continuer ?',
    'discovery_seed_success' => '%d nouvelle(s) vidéo(s), %d au total, avec %d recherche(s) réussie(s).',
    'discovery_seed_failed' => 'Le réservoir n’a pas pu être enrichi. Vérifiez la clé, le quota et le journal.',
    'discovery_count' => 'Vidéos dans le réservoir',
    'discovery_last_refresh' => 'Dernier renouvellement',
    'discovery_last_seed' => 'Dernier amorçage complet',
    'storage_active_path' => 'Dossier de données persistant actif',
    'storage_legacy_path' => 'Ancien dossier conservé',
    'storage_migration_result' => 'Migration du stockage',
    'storage_migration_counts' => '%d fichier(s) copié(s), %d déjà présent(s), %d ignoré(s) car invalide(s) ou illisible(s)',
    'video' => 'Vidéo',
    'seo_diagnostic' => 'Aperçu des métadonnées SEO',
    'seo_diagnostic_help' => 'Aperçu produit avec la première vidéo classée localement. Aucun appel à YouTube n’est effectué.',
    'seo_diagnostic_empty' => 'Aucune vidéo classée en cache n’est encore disponible pour cet aperçu.',
    'faq_title' => 'Questions fréquentes',
    'video_about_title' => 'À propos de cette vidéo'
);







































// 0.19.0 unified admin interface strings
$LANG_VIDEOS['admin_actions_column'] = 'Actions';
$LANG_VIDEOS['admin_cache_label'] = 'Cache';
$LANG_VIDEOS['admin_yes'] = 'Oui';
$LANG_VIDEOS['admin_no'] = 'Non';
$LANG_VIDEOS['admin_status_ok'] = 'OK';
$LANG_VIDEOS['admin_remove_help'] = 'enlève la vidéo du catalogue permanent, mais elle pourra être sélectionnée de nouveau.';
$LANG_VIDEOS['admin_exclude_help'] = 'l’empêche d’être réintégrée tant qu’elle n’est pas réautorisée.';
$LANG_VIDEOS['admin_consult'] = 'Consultez';
$LANG_VIDEOS['admin_byte_unit'] = 'o';
// END 0.19.0 unified admin interface strings

// 0.18.0 interface strings
$LANG_VIDEOS['admin_nav_overview'] = 'Vue générale';
$LANG_VIDEOS['admin_nav_actions'] = 'Actions';
$LANG_VIDEOS['admin_nav_stats'] = 'Statistiques';
$LANG_VIDEOS['admin_nav_moderation'] = 'Modération';
$LANG_VIDEOS['admin_navigation'] = 'Administration Videos';
$LANG_VIDEOS['catalogue_disabled'] = 'Le catalogue vidéo est désactivé.';
$LANG_VIDEOS['catalogue_unavailable'] = 'Le catalogue vidéo est temporairement indisponible.';
$LANG_VIDEOS['catalogue_search_unavailable'] = 'La recherche vidéo est temporairement indisponible.';
$LANG_VIDEOS['catalogue_search_empty'] = 'Aucune vidéo du catalogue ne correspond à cette recherche.';
$LANG_VIDEOS['catalogue_topic_required'] = 'La thématique vidéo doit être configurée par un administrateur.';
$LANG_VIDEOS['catalogue_none_available'] = 'Aucune vidéo n’est actuellement disponible.';
$LANG_VIDEOS['catalogue_search_label'] = 'Rechercher dans le catalogue';
$LANG_VIDEOS['catalogue_search_placeholder'] = 'Titre, chaîne ou mots-clés';
$LANG_VIDEOS['catalogue_search_button'] = 'Rechercher';
$LANG_VIDEOS['catalogue_search_help'] = 'La recherche utilise les vidéos déjà connues du site et ne consomme aucun quota YouTube supplémentaire.';
$LANG_VIDEOS['catalogue_search_results'] = 'résultat(s) pour « %s ».';
$LANG_VIDEOS['catalogue_show_all'] = 'Afficher tout le catalogue';
$LANG_VIDEOS['catalogue_search_page_title'] = 'Recherche « %s »';
$LANG_VIDEOS['channel_unavailable'] = 'Chaîne vidéo indisponible.';
$LANG_VIDEOS['channel_temporarily_unavailable'] = 'Chaîne vidéo temporairement indisponible.';
$LANG_VIDEOS['channel_not_published'] = 'Cette chaîne n’est pas publiée.';
$LANG_VIDEOS['channel_insufficient_selection'] = 'Cette chaîne ne dispose pas encore d’une sélection éditoriale suffisante.';
$LANG_VIDEOS['channel_meta_fallback'] = 'Découvrez les vidéos remarquables de %s sélectionnées dans %s.';
$LANG_VIDEOS['channel_priority_badge'] = 'Chaîne prioritaire';
$LANG_VIDEOS['channel_pinned_video'] = 'vidéo épinglée';
$LANG_VIDEOS['channel_pinned_videos'] = 'vidéos épinglées';
$LANG_VIDEOS['channel_information'] = 'Informations sur la chaîne';
$LANG_VIDEOS['channel_subscribers'] = 'Abonnés';
$LANG_VIDEOS['channel_youtube_views'] = 'Vues YouTube';
$LANG_VIDEOS['channel_youtube_videos'] = 'Vidéos sur YouTube';
$LANG_VIDEOS['channel_local_videos'] = 'Vidéos remarquables locales';
$LANG_VIDEOS['channel_permanent_selection'] = 'Sélection permanente';
$LANG_VIDEOS['channel_created'] = 'Chaîne créée';
$LANG_VIDEOS['channel_about'] = 'À propos de la chaîne';
$LANG_VIDEOS['channel_view_youtube'] = 'Voir la chaîne sur YouTube';
$LANG_VIDEOS['channel_featured_videos'] = 'Vidéos remarquables';
$LANG_VIDEOS['channel_pinned_badge'] = 'Épinglée';

// 0.18.0 public channels directory
$LANG_VIDEOS['channels'] = 'Chaînes';
$LANG_VIDEOS['channels_title'] = 'Chaînes vidéo recommandées';
$LANG_VIDEOS['channels_intro'] = 'Découvrez les chaînes retenues pour leur intérêt éditorial et leurs vidéos remarquables.';
$LANG_VIDEOS['channels_meta_description'] = 'Découvrez les chaînes vidéo recommandées et leurs vidéos remarquables sélectionnées sur ce site.';
$LANG_VIDEOS['channels_empty'] = 'Aucune chaîne recommandée n’est encore disponible.';
$LANG_VIDEOS['channels_unavailable'] = 'L’annuaire des chaînes est temporairement indisponible.';
$LANG_VIDEOS['channels_view_channel'] = 'Voir les vidéos de cette chaîne';


$LANG_VIDEOS_FAQ = array(
    'catalogue_selection_q' => 'Comment les vidéos du catalogue sont-elles sélectionnées ?',
    'catalogue_selection_a' => 'Le plugin combine la thématique du site, les réglages administratifs, la disponibilité sur YouTube et les recommandations locales. Les vidéos bloquées, privées ou non intégrables sont exclues.',
    'catalogue_changes_q' => 'Pourquoi le catalogue peut-il changer ?',
    'catalogue_changes_a' => 'Les recherches YouTube sont renouvelées à travers un cache respectueux du quota. Les vidéos appréciées peuvent rester dans le fonds permanent tandis que les vidéos indisponibles ou modérées sont retirées.',
    'catalogue_ratings_q' => 'Comment fonctionnent les notes locales ?',
    'catalogue_ratings_a' => 'Une note de une à cinq étoiles devient disponible après une lecture réelle. Un visiteur peut modifier sa note et la valeur précédente est alors remplacée.',
    'catalogue_privacy_q' => 'Un compte est-il nécessaire pour regarder une vidéo ?',
    'catalogue_privacy_a' => 'Aucun compte n’est nécessaire. Lorsque le suivi est activé, l’activité anonyme utilise un identifiant pseudonyme et aucune adresse IP en clair n’est enregistrée.',
    'video_ranking_score_q' => 'Comment les vidéos sont-elles classées ?',
    'video_ranking_score_a' => 'Le classement utilise une note pondérée plutôt que la moyenne brute, avec les vues qualifiées, le taux de lecture, la récence et le comportement face aux recommandations.',
    'video_ranking_views_q' => 'Qu’est-ce qu’une vue qualifiée ?',
    'video_ranking_views_a' => 'Une vue est comptabilisée uniquement lorsque le seuil configuré de durée ou de pourcentage de lecture a été atteint.',
    'channel_ranking_score_q' => 'Comment les chaînes sont-elles classées ?',
    'channel_ranking_score_a' => 'Le score local combine les notes, les vues qualifiées, la diversité des vidéos appréciées, la récence et les performances des vidéos classées.',
    'channel_ranking_diversity_q' => 'Une même chaîne peut-elle occuper toutes les recommandations ?',
    'channel_ranking_diversity_a' => 'Non. Une limite de diversité configurable restreint le nombre de vidéos de la même chaîne dans une liste.',
    'ranking_update_q' => 'Quand les classements sont-ils actualisés ?',
    'ranking_update_a' => 'Ils sont mis à jour après une activité pertinente et peuvent être reconstruits par un administrateur. Les recalculs complets sont espacés pour préserver les performances.',
    'video_channel_q' => 'Quelle chaîne a publié cette vidéo ?',
    'video_channel_a' => 'Cette vidéo est publiée par la chaîne YouTube %channel%.',
    'video_duration_q' => 'Quelle est la durée de cette vidéo ?',
    'video_duration_a' => 'La durée communiquée par YouTube est de %duration%.',
    'video_publication_q' => 'Quand cette vidéo a-t-elle été publiée ?',
    'video_publication_a' => 'YouTube indique une date de publication au %published%.',
    'video_selection_q' => 'Pourquoi cette vidéo est-elle proposée ici ?',
    'video_selection_a' => 'Elle correspond à la thématique du site et aux filtres configurés, sous réserve des règles locales de modération, de disponibilité et de recommandation.',
    'video_rating_q' => 'Quelle est sa note locale ?',
    'video_rating_a' => 'Sa moyenne locale actuelle est de %average% sur 5, calculée à partir de %count% note(s) active(s).',
    'unknown_value' => 'information indisponible'
);

$LANG_VIDEOS_TOOLTIPS = array(
    'enabled' => 'Active le catalogue public et les fonctions du plugin. Vous pouvez le désactiver temporairement sans le désinstaller ni supprimer ses données JSON.',
    'public_title' => 'Titre affiché dans le catalogue public et la navigation. La valeur initiale suit la langue de Geeklog.',
    'language' => 'Code ISO de langue envoyé à YouTube, par exemple fr ou en. Il améliore la pertinence sans garantir la langue de toutes les vidéos.',
    'region' => 'Code pays ISO 3166-1 sur deux lettres, par exemple FR, BE, CA ou CH. Il est déduit de la locale Geeklog lorsque cela est possible.',
    'videos_per_page' => 'Nombre maximal de vidéos affichées sur une page du catalogue. Valeur conseillée : 12.',
    'suggestion_count' => 'Nombre de vidéos similaires ou suivantes préparées pour une page de lecture. Valeur conseillée : 6.',
    'sharing_enabled' => 'Affiche les liens de partage. Aucun script de réseau social n’est chargé et le lien partagé pointe vers ce site Geeklog.',
    'ratings_enabled' => 'Autorise les visiteurs à attribuer une note de 1 à 5 après le seuil réel de lecture configuré.',
    'view_tracking_enabled' => 'Enregistre une vue qualifiée seulement après le seuil de temps ou de pourcentage. Aucune écriture n’est effectuée chaque seconde.',
    'exclude_short_videos' => 'Active l’exclusion des Shorts selon le mode choisi. L’API YouTube ne fournit pas d’indicateur Shorts officiel.',
    'short_filter_mode' => 'Shorts probables recherche un marqueur explicite dans le titre, la description ou les tags et préserve les vidéos courtes classiques. Le mode strict exclut toutes les vidéos sous le seuil.',
    'short_max_duration' => 'Durée maximale assimilée à un format court, en secondes. YouTube autorise actuellement des Shorts jusqu’à 180 secondes. Valeurs acceptées : 1 à 600.',
    'youtube_daily_search_limit' => 'Nombre maximal de requêtes coûteuses search.list par jour UTC. Les détails vidéo et chaîne sont mis en cache séparément. Valeur conseillée : 20.',
    'youtube_timeout' => 'Durée maximale d’une connexion à l’API YouTube, en secondes. Une valeur courte protège l’hébergement mutualisé. Valeur conseillée : 8.',
    'search_cache_ttl' => 'Durée du cache des résultats de recherche, en secondes. 86400 correspond à 24 heures. Les anciens résultats restent utilisables si l’API échoue.',
    'video_cache_ttl' => 'Durée du cache des informations vidéo, en secondes. 86400 correspond à 24 heures.',
    'channel_cache_ttl' => 'Durée du cache des informations de chaîne, en secondes. 604800 correspond à 7 jours.',
    'availability_cache_ttl' => 'Durée d’une vérification de disponibilité YouTube, en secondes. 86400 correspond à 24 heures. Une vidéo connue comme indisponible reste exclue jusqu’à une réponse API valide ultérieure.',
    'youtube_max_results' => 'Nombre maximal de résultats demandés à YouTube pour une recherche, de 1 à 50. Valeur conseillée : 20.',
    'discovery_enabled' => 'Conserve les découvertes dans un réservoir JSON partagé afin de proposer un grand catalogue sans appel API à chaque page.',
    'discovery_reservoir_size' => 'Nombre maximal de références conservées. Valeur conseillée : 500.',
    'catalogue_max_videos' => 'Nombre maximal de vidéos proposées dans le catalogue paginé. Valeur conseillée : 300.',
    'discovery_seed_searches' => 'Nombre de recherches de 50 résultats lors d’un amorçage manuel, de 1 à 12. Huit recherches consomment environ 800 unités YouTube.',
    'discovery_refresh_interval' => 'Intervalle minimal en secondes entre deux renouvellements automatiques partagés. Valeur conseillée : 86400.',
    'discovery_refresh_percentage' => 'Part approximative du réservoir recherchée à chaque renouvellement. Valeur conseillée : 10 %.',
    'discovery_recent_percentage' => 'Part cible de vidéos publiées récemment dans le réservoir présenté. Valeur conseillée : 30 %.',
    'discovery_recent_months' => 'Une vidéo est considérée récente si elle a été publiée dans ce nombre de mois. Valeur conseillée : 12.',
    'youtube_safe_search' => 'Niveau SafeSearch YouTube : none, moderate ou strict. Valeur conseillée pour un site public : moderate.',
    'analysis_mode' => 'Source des mots-clés : manual, automatic ou mixed. Le mode mixed combine analyse du site et mots-clés administrateur ; il est conseillé.',
    'manual_keywords' => 'Termes séparés par des virgules décrivant le site. Ils renforcent ou remplacent les termes détectés selon le mode d’analyse.',
    'required_keywords' => 'Termes séparés par des virgules qui doivent figurer dans la requête YouTube maîtrisée.',
    'excluded_keywords' => 'Mots ou expressions séparés par des virgules à exclure des requêtes et des vidéos candidates.',
    'additional_stop_words' => 'Mots courants séparés par des virgules que l’analyseur doit ignorer en plus de sa liste interne.',
    'max_keywords' => 'Nombre maximal de termes sélectionnés et envoyés à YouTube. Une requête courte est plus stable. Valeur conseillée : 8.',
    'title_weight' => 'Importance relative des termes trouvés dans les titres. Valeur conseillée : 5.',
    'meta_weight' => 'Importance relative des termes trouvés dans les descriptions et mots-clés meta. Valeur conseillée : 4.',
    'content_weight' => 'Importance relative des termes trouvés dans le contenu visible de la page. Valeur conseillée : 1.',
    'allowed_channels' => 'Identifiants de chaînes YouTube séparés par des virgules. Si cette liste blanche est utilisée, les autres chaînes sont rejetées.',
    'priority_channels' => 'Identifiants de chaînes YouTube séparés par des virgules à favoriser sans exclure les autres chaînes.',
    'blocked_channels' => 'Identifiants de chaînes YouTube séparés par des virgules qui ne doivent jamais être affichées.',
    'blocked_videos' => 'Identifiants de vidéos YouTube séparés par des virgules qui ne doivent jamais être affichées.',
    'description_mode' => 'Contrôle la description : clean sélectionne jusqu’à deux phrases informatives et retire le contenu promotionnel ; hidden n’affiche rien ; raw restaure la description brute tronquée.',
    'youtube_player_mode' => 'standard conserve les contrôles YouTube accessibles. minimal masque la barre de contrôle et le plein écran afin de réduire les possibilités de sortie, mais supprime aussi progression, volume, sous-titres et plein écran. YouTube peut toujours afficher son titre, son logo, ses liens et ses recommandations finales.',
    'privacy_enhanced_embed' => 'Utilise youtube-nocookie.com pour le lecteur intégré. Activé par défaut et conseillé.',
    'autoplay' => 'Démarre automatiquement la lecture si le navigateur l’autorise. Désactivé par défaut pour préserver la bande passante et éviter une lecture inattendue.',
    'rating_threshold_seconds' => 'Temps de lecture nécessaire avant d’autoriser la notation, en secondes. Pour une vidéo plus courte, 90 % de sa durée est retenu afin que le seuil reste atteignable. Valeur conseillée : 30.',
    'view_threshold_seconds' => 'Temps nécessaire pour qualifier une vue locale, en secondes. Le premier seuil temps/pourcentage atteint est retenu.',
    'view_threshold_percent' => 'Pourcentage de la durée nécessaire pour qualifier une vue locale. Valeur conseillée : 25.',
    'ranking_rebuild_interval' => 'Intervalle minimal entre deux reconstructions complètes des classements, en secondes. 3600 correspond à une heure.',
    'max_same_channel' => 'Nombre maximal de vidéos d’une même chaîne dans une liste de recommandations. Valeur conseillée : 2.',
    'permanent_pool_enabled' => 'Mélange au catalogue des vidéos locales appréciées afin qu’elles ne disparaissent pas lors d’une nouvelle recherche.',
    'permanent_pool_size' => 'Nombre maximal de vidéos conservées dans le fonds permanent. Valeur conseillée : 24.',
    'permanent_pool_percentage' => 'Part maximale du catalogue réservée au fonds permanent. Valeur conseillée : 25 %.',
    'permanent_pool_auto' => 'Admet automatiquement les vidéos qui atteignent le nombre de notes et la note pondérée configurés.',
    'permanent_pool_min_ratings' => 'Nombre minimal de notes locales avant une admission automatique. Valeur conseillée : 3.',
    'permanent_pool_min_weighted_rating' => 'Note bayésienne pondérée minimale sur 5. Une seule note excellente ne suffit donc pas. Valeur conseillée : 4,0.',
    'permanent_pool_keep_below_threshold' => 'Conserve une vidéo déjà admise si son score baisse ensuite. La taille maximale, les blocages et la disponibilité restent prioritaires.',
    'public_rankings_enabled' => 'Affiche une page de classements accessible à tous les visiteurs et l’ajoute à la navigation Vidéos.',
    'public_video_ranking_enabled' => 'Affiche le classement local simplifié des vidéos sur la page publique.',
    'public_channel_ranking_enabled' => 'Affiche le classement local simplifié des chaînes sur la page publique.',
    'public_ranking_limit' => 'Nombre maximal de vidéos et de chaînes affichées dans chaque classement public. Valeur conseillée : 10.',
    'account_history_enabled' => 'Associe les vidéos regardées et notées à un compte enregistré au moyen d’un identifiant HMAC pseudonyme.',
    'account_recommendations_enabled' => 'Autorise l’historique et les notes du compte à influencer les recommandations futures.',
    'anonymous_tracking_enabled' => 'Utilise un cookie visiteur aléatoire et pseudonyme pour les vues qualifiées et les notes. Aucune adresse IP en clair n’est stockée.',
    'allow_anonymous_merge' => 'Autorise l’association de l’historique anonyme admissible au compte enregistré après identification.',
    'allow_user_export' => 'Autorise un utilisateur enregistré à obtenir ses données du plugin au format JSON lorsque l’interface d’export est disponible.',
    'allow_user_deletion' => 'Autorise un utilisateur enregistré à supprimer explicitement son historique du plugin lorsque l’interface sera disponible.',
    'account_retention_days' => 'Doit rester à 0 : l’historique d’un compte est conservé jusqu’à sa suppression par l’utilisateur.',
    'automatic_account_purge' => 'Doit rester désactivé. Aucun historique de compte n’est purgé automatiquement.',
    'anonymous_retention_days' => 'Durée de conservation des identifiants et historiques des visiteurs anonymes, en jours. Valeur conseillée : 90.',
    'privacy_notice' => 'Court texte d’information affiché aux visiteurs. Expliquez le cookie pseudonyme, l’historique de lecture et les notes.',
    'block_enabled' => 'Crée ou active le bloc Geeklog Videos facultatif. Laissez-le désactivé avant d’avoir vérifié son emplacement avec le thème actif.',
    'block_isleft' => 'Place le bloc facultatif dans la colonne gauche lorsqu’il est activé ; sinon Geeklog le place dans la colonne droite.',
    'block_order' => 'Ordre d’affichage Geeklog du bloc dans sa colonne. Les valeurs les plus faibles sont affichées en premier.',
    'block_mode' => 'Sélectionnez le contenu du bloc facultatif, une sélection aléatoire de vidéos ou un tirage parmi les six modes de contenu. Aucun mode ne provoque d’appel YouTube supplémentaire.',
    'block_item_count' => 'Nombre d’éléments affichés dans le bloc facultatif, de 1 à 10. Valeur conseillée : 3.',
    'seo_enabled' => 'Active les métadonnées SEO. Les pages privées et indisponibles restent toujours en noindex.',
    'seo_catalogue_index' => 'Autorise l’indexation des pages non vides du catalogue.',
    'seo_rankings_index' => 'Autorise l’indexation des onglets publics de classement non vides.',
    'seo_structured_data' => 'Ajoute un objet VideoObject JSON-LD schema.org aux pages de lecture valides à partir du cache YouTube.',
    'seo_social_metadata' => 'Ajoute les métadonnées Open Graph et Twitter Card sans charger de script de réseau social.',
    'seo_description_fallback' => 'Meta description générique facultative. Laissez vide pour produire une description factuelle adaptée à la page.',
    'faq_catalogue_enabled' => 'Affiche une FAQ utile sous la première page non vide du catalogue.',
    'faq_video_enabled' => 'Affiche des informations factuelles dynamiques sous chaque page de lecture valide.',
    'faq_rankings_enabled' => 'Affiche une FAQ explicative adaptée à l’onglet de classement public actif.',
    'faq_structured_data' => 'Expérimental : ajoute un JSON-LD FAQPage correspondant à la FAQ visible. Désactivé par défaut car les résultats enrichis FAQ ne sont généralement pas proposés à ce type de site.',
    'technical_log_days' => 'Durée de conservation des journaux techniques limités, en jours. Ils excluent la clé API et les données personnelles inutiles.'
);

$LANG_configsections['videos'] = array(
    'label' => 'Vidéos',
    'title' => 'Configuration du plugin Vidéos'
);

$LANG_configsubgroups['videos'] = array(
    'sg_main' => 'Paramètres principaux'
);

$LANG_tab['videos'] = array(
    'tab_general' => 'Général',
    'tab_youtube' => 'API YouTube',
    'tab_analysis' => 'Analyse du site',
    'tab_sources' => 'Vidéos et chaînes',
    'tab_ranking' => 'Notes et recommandations',
    'tab_privacy' => 'Vie privée',
    'tab_block' => 'Bloc',
    'tab_seo' => 'SEO',
    'tab_maintenance' => 'Maintenance'
);

$LANG_fs['videos'] = array(
    'fs_general' => 'Paramètres généraux',
    'fs_youtube' => 'YouTube Data API v3',
    'fs_analysis' => 'Analyse des mots-clés',
    'fs_sources' => 'Vidéos et chaînes',
    'fs_ranking' => 'Notes et recommandations',
    'fs_privacy' => 'Vie privée et conservation',
    'fs_block' => 'Bloc Geeklog',
    'fs_seo' => 'Référencement des pages publiques',
    'fs_maintenance' => 'Maintenance'
);

$LANG_confignames['videos'] = array(
    'enabled' => 'Plugin activé',
    'public_title' => 'Titre public',
    'language' => 'Langue',
    'region' => 'Région',
    'videos_per_page' => 'Vidéos par page',
    'suggestion_count' => 'Nombre de suggestions',
    'sharing_enabled' => 'Activer le partage',
    'ratings_enabled' => 'Activer les notes',
    'view_tracking_enabled' => 'Activer le suivi des lectures',
    'youtube_daily_search_limit' => 'Limite quotidienne de recherches',
    'youtube_timeout' => 'Délai maximal de connexion',
    'search_cache_ttl' => 'Durée du cache des recherches',
    'video_cache_ttl' => 'Durée du cache des vidéos',
    'channel_cache_ttl' => 'Durée du cache des chaînes',
    'availability_cache_ttl' => 'Durée des vérifications de disponibilité',
    'youtube_max_results' => 'Nombre maximal de résultats',
    'discovery_enabled' => 'Activer le réservoir de découverte',
    'discovery_reservoir_size' => 'Capacité du réservoir',
    'catalogue_max_videos' => 'Taille maximale du catalogue',
    'discovery_seed_searches' => 'Recherches par amorçage',
    'discovery_refresh_interval' => 'Intervalle de renouvellement',
    'discovery_refresh_percentage' => 'Proportion renouvelée',
    'discovery_recent_percentage' => 'Proportion de vidéos récentes',
    'discovery_recent_months' => 'Ancienneté maximale des vidéos récentes',
    'youtube_safe_search' => 'Niveau de modération',
    'analysis_mode' => 'Mode d’analyse',
    'manual_keywords' => 'Mots-clés manuels',
    'required_keywords' => 'Mots-clés obligatoires',
    'excluded_keywords' => 'Mots-clés exclus',
    'additional_stop_words' => 'Mots vides supplémentaires',
    'max_keywords' => 'Nombre maximal de mots-clés',
    'title_weight' => 'Poids du titre',
    'meta_weight' => 'Poids des balises meta',
    'content_weight' => 'Poids du contenu',
    'allowed_channels' => 'Chaînes autorisées',
    'priority_channels' => 'Chaînes prioritaires',
    'blocked_channels' => 'Chaînes interdites',
    'blocked_videos' => 'Vidéos bloquées',
    'exclude_short_videos' => 'Exclure les formats courts (Shorts)',
    'short_filter_mode' => 'Méthode de détection des Shorts',
    'short_max_duration' => 'Seuil des formats courts en secondes',
    'description_mode' => 'Description des vidéos',
    'youtube_player_mode' => 'Mode du lecteur YouTube',
    'privacy_enhanced_embed' => 'Intégration respectueuse de la vie privée',
    'autoplay' => 'Lecture automatique',
    'rating_threshold_seconds' => 'Seuil de notation en secondes',
    'view_threshold_seconds' => 'Seuil de vue en secondes',
    'view_threshold_percent' => 'Seuil de vue en pourcentage',
    'ranking_rebuild_interval' => 'Fréquence de recalcul du classement',
    'max_same_channel' => 'Maximum de vidéos de la même chaîne',
    'permanent_pool_enabled' => 'Activer le fonds permanent',
    'permanent_pool_size' => 'Taille maximale du fonds',
    'permanent_pool_percentage' => 'Proportion du catalogue en pourcentage',
    'permanent_pool_auto' => 'Admission automatique',
    'permanent_pool_min_ratings' => 'Nombre minimal de notes',
    'permanent_pool_min_weighted_rating' => 'Note pondérée minimale',
    'permanent_pool_keep_below_threshold' => 'Conserver après une baisse du score',
    'public_rankings_enabled' => 'Activer la page publique des classements',
    'public_video_ranking_enabled' => 'Afficher le classement des vidéos',
    'public_channel_ranking_enabled' => 'Afficher le classement des chaînes',
    'public_ranking_limit' => 'Taille des classements publics',
    'account_history_enabled' => 'Historique des comptes enregistrés',
    'account_recommendations_enabled' => 'Recommandations personnelles',
    'anonymous_tracking_enabled' => 'Suivi anonyme',
    'allow_anonymous_merge' => 'Autoriser la fusion de l’historique anonyme',
    'allow_user_export' => 'Autoriser l’export utilisateur',
    'allow_user_deletion' => 'Autoriser la suppression utilisateur',
    'account_retention_days' => 'Conservation des comptes enregistrés',
    'automatic_account_purge' => 'Purge automatique des comptes',
    'anonymous_retention_days' => 'Conservation anonyme en jours',
    'privacy_notice' => 'Texte d’information sur la vie privée',
    'block_enabled' => 'Activer le bloc',
    'block_isleft' => 'Afficher le bloc à gauche',
    'block_order' => 'Ordre du bloc',
    'block_mode' => 'Mode du bloc',
    'block_item_count' => 'Nombre d’éléments du bloc',
    'seo_enabled' => 'Activer les métadonnées SEO',
    'seo_catalogue_index' => 'Indexer le catalogue',
    'seo_rankings_index' => 'Indexer les classements publics',
    'seo_structured_data' => 'Données structurées VideoObject',
    'seo_social_metadata' => 'Métadonnées Open Graph et Twitter',
    'seo_description_fallback' => 'Meta description de remplacement',
    'faq_catalogue_enabled' => 'FAQ du catalogue',
    'faq_video_enabled' => 'Informations sous les vidéos',
    'faq_rankings_enabled' => 'FAQ des classements',
    'faq_structured_data' => 'Données FAQPage expérimentales',
    'technical_log_days' => 'Conservation des journaux techniques'
);

$LANG_configselects['videos'] = array(
    0 => array('Oui' => 1, 'Non' => 0),
    1 => array(
        'Extrait informatif nettoyé' => 'clean',
        'Masquée' => 'hidden',
        'Description brute tronquée' => 'raw'
    ),
    2 => array(
        'Contrôles standards' => 'standard',
        'Lecteur épuré' => 'minimal'
    ),
    3 => array(
        'Recommandées (score local combiné)' => 'recommended',
        'Meilleures notes pondérées (bayésien)' => 'top_rated',
        'Plus regardées (vues qualifiées)' => 'most_watched',
        'Regardées récemment sur ce site' => 'recent_activity',
        'Sélection aléatoire de vidéos' => 'random',
        'Meilleures chaînes (score local)' => 'best_channels',
        'Mode aléatoire parmi les 6 modes' => 'random_mode'
    ),
    4 => array(
        'Shorts probables (recommandé)' => 'probable',
        'Toutes les vidéos sous le seuil (strict)' => 'strict'
    )
);

// Videos 0.19.0 semantic administration strings
$LANG_VIDEOS['admin_explicit_editorial_exclusions'] = 'Exclusions éditoriales explicites';
$LANG_VIDEOS['admin_youtube_data_api_key_has_been_saved'] = 'La clé YouTube Data API a été enregistrée.';
$LANG_VIDEOS['admin_videos_list_details'] = 'Détails videos.list';
$LANG_VIDEOS['admin_video_seo'] = 'SEO vidéo : ';
$LANG_VIDEOS['admin_editorial_decision_saved'] = 'Décision éditoriale enregistrée.';
$LANG_VIDEOS['admin_all_statistics'] = 'Toutes les statistiques';
$LANG_VIDEOS['admin_local_video_corpus_available_native_search'] = 'Le corpus vidéo local est disponible dans la recherche native.';
$LANG_VIDEOS['admin_public_pages'] = 'Pages publiques :';
$LANG_VIDEOS['admin_availability'] = 'Disponibilité';
$LANG_VIDEOS['admin_partial_cleanup'] = 'Nettoyage partiel : ';
$LANG_VIDEOS['admin_send_existing_pages_indexnow'] = 'Envoyer les pages existantes à IndexNow';
$LANG_VIDEOS['admin_pinned'] = 'Épinglée';
$LANG_VIDEOS['admin_video_curation'] = 'Curation vidéo';
$LANG_VIDEOS['admin_channel_information'] = 'Informations des chaînes';
$LANG_VIDEOS['admin_last_success'] = 'Dernier succès';
$LANG_VIDEOS['admin_priority_channels'] = 'Chaînes prioritaires';
$LANG_VIDEOS['admin_last_api_error'] = 'Dernière erreur API';
$LANG_VIDEOS['admin_videos_retained_permanently'] = 'Vidéos conservées durablement';
$LANG_VIDEOS['admin_video_added_permanent_catalogue'] = 'Vidéo ajoutée au catalogue permanent.';
$LANG_VIDEOS['admin_at_glance'] = 'Repères';
$LANG_VIDEOS['admin_iteminfo_interoperability'] = 'Interopérabilité ItemInfo';
$LANG_VIDEOS['admin_catalogue_search'] = 'Recherche du catalogue';
$LANG_VIDEOS['admin_geeklog_search'] = 'Recherche Geeklog';
$LANG_VIDEOS['admin_add_permanent_catalogue'] = 'Ajouter au catalogue permanent';
$LANG_VIDEOS['admin_geeklog_integration'] = 'Intégration Geeklog';
$LANG_VIDEOS['admin_quota_suspended'] = 'Quota suspendu';
$LANG_VIDEOS['admin_video_s_added_reservoir'] = ' vidéo(s) ajoutée(s) au réservoir.';
$LANG_VIDEOS['admin_youtube_quota_suspended'] = 'Le quota YouTube est suspendu (';
$LANG_VIDEOS['admin_local_search_limit'] = 'Limite locale recherches';
$LANG_VIDEOS['admin_last_search'] = 'Dernière recherche';
$LANG_VIDEOS['admin_https_youtu_be'] = ' ou https://youtu.be/…';
$LANG_VIDEOS['admin_video'] = 'Vidéo';
$LANG_VIDEOS['admin_youtube_id_url'] = 'ID ou URL YouTube';
$LANG_VIDEOS['admin_public_corpus_used_by_geeklog_catalogue'] = 'Corpus public utilisé par Geeklog et le catalogue';
$LANG_VIDEOS['admin_permanent_catalogue'] = 'Catalogue permanent';
$LANG_VIDEOS['admin_index_existing_pages'] = 'Indexation des pages existantes';
$LANG_VIDEOS['admin_test_search'] = 'Recherche de test';
$LANG_VIDEOS['admin_size'] = 'Volume';
$LANG_VIDEOS['admin_open_repair_tools'] = 'Ouvrir les outils de réparation';
$LANG_VIDEOS['admin_ranking_rebuild_failed'] = 'La reconstruction des classements a échoué.';
$LANG_VIDEOS['admin_seed_reservoir'] = 'Amorcer le réservoir';
$LANG_VIDEOS['admin_last_youtube_error'] = 'Dernière erreur YouTube : ';
$LANG_VIDEOS['admin_video_catalogue_status_quick_actions_geeklog_integrati'] = 'État du catalogue vidéo, accès rapides et intégrations Geeklog.';
$LANG_VIDEOS['admin_cache_entrie_s_deleted'] = ' entrée(s) de cache supprimée(s).';
$LANG_VIDEOS['admin_pinned_videos'] = 'Vidéos épinglées';
$LANG_VIDEOS['admin_last_rejected_call'] = 'Dernier appel refusé :';
$LANG_VIDEOS['admin_availability_checks'] = 'Vérifications de disponibilité';
$LANG_VIDEOS['admin_permanent'] = 'Permanente';
$LANG_VIDEOS['admin_last_valid_api_response'] = 'Dernière réponse API valide';
$LANG_VIDEOS['admin_videos_with_local_signals'] = 'Vidéos ayant des signaux locaux';
$LANG_VIDEOS['admin_local_youtube_search_limit_has_been_reached'] = 'La limite locale de recherches YouTube est atteinte (';
$LANG_VIDEOS['admin_youtube_data_api_key_required_search_new'] = 'Une clé YouTube Data API est nécessaire pour rechercher de nouvelles vidéos et récupérer les données d’une vidéo qui n’est pas encore en cache. Les vidéos déjà mises en cache restent consultables sans nouvel appel API.';
$LANG_VIDEOS['admin_integrations'] = 'Intégrations';
$LANG_VIDEOS['admin_videos_excluded_from_pool'] = 'Vidéos exclues du fonds';
$LANG_VIDEOS['admin_rebuild_rankings'] = 'Reconstruire les classements';
$LANG_VIDEOS['admin_public_editorial_content'] = 'Contenu public et éditorial';
$LANG_VIDEOS['admin_search_results'] = 'Résultats de recherche';
$LANG_VIDEOS['admin_active'] = 'Active';
$LANG_VIDEOS['admin_never'] = 'Jamais';
$LANG_VIDEOS['admin_test_search_8cfd'] = 'Tester la recherche';
$LANG_VIDEOS['admin_videos_plugin_storage_unavailable_use_repair_tools'] = 'Le stockage du plugin Videos est indisponible. Consultez les outils de réparation.';
$LANG_VIDEOS['admin_videos_reservoir'] = 'Vidéos dans le réservoir';
$LANG_VIDEOS['admin_catalogue'] = 'Catalogue';
$LANG_VIDEOS['admin_videos_public_pages'] = 'Pages publiques Videos';
$LANG_VIDEOS['admin_seed_query'] = 'Requête d’amorçage';
$LANG_VIDEOS['admin_no_video_available_seo_diagnostics'] = 'Aucune vidéo disponible pour le diagnostic SEO.';
$LANG_VIDEOS['admin_video_calls'] = 'Appels vidéos';
$LANG_VIDEOS['admin_api_key_invalid'] = 'La clé API est invalide.';
$LANG_VIDEOS['admin_technical_diagnostics'] = 'Diagnostic technique';
$LANG_VIDEOS['admin_compatible'] = 'Compatible';
$LANG_VIDEOS['admin_youtube_api_activity'] = 'Activité YouTube API';
$LANG_VIDEOS['admin_videos_url_s_sent_indexnow_one_batch'] = ' URL(s) Videos envoyée(s) à IndexNow en un seul batch.';
$LANG_VIDEOS['admin_searches_today'] = 'Recherches aujourd’hui';
$LANG_VIDEOS['admin_video_currently_blocked_by_moderation'] = 'Cette vidéo est actuellement bloquée par la modération.';
$LANG_VIDEOS['admin_unpin'] = 'Désépingler';
$LANG_VIDEOS['admin_deleted'] = ' supprimée(s), ';
$LANG_VIDEOS['admin_exclude_from_future_selections'] = 'Exclure des sélections futures';
$LANG_VIDEOS['admin_video_information'] = 'Informations des vidéos';
$LANG_VIDEOS['admin_ranked_videos'] = 'Vidéos classées';
$LANG_VIDEOS['admin_limit_reached'] = 'Limite atteinte (';
$LANG_VIDEOS['admin_status'] = 'État :';
$LANG_VIDEOS['admin_add_video'] = 'Ajouter une vidéo';
$LANG_VIDEOS['admin_configuration'] = 'Configuration';
$LANG_VIDEOS['admin_video_unavailable_private_not_embeddable_rejected_by'] = 'La vidéo est introuvable, privée, non intégrable ou refusée par la politique du plugin.';
$LANG_VIDEOS['admin_replace_api_key'] = 'Remplacer la clé API';
$LANG_VIDEOS['admin_last_authorized_search_list_reservation'] = 'Dernière réservation search.list autorisée';
$LANG_VIDEOS['admin_test_search_failed'] = 'La recherche de test a échoué.';
$LANG_VIDEOS['admin_unavailable'] = 'Indisponible';
$LANG_VIDEOS['admin_search_list_calls'] = 'Appels search.list';
$LANG_VIDEOS['admin_strong_selections_including_legacy_0_17_pins'] = 'Sélections fortes, y compris les anciens épinglages 0.17';
$LANG_VIDEOS['admin_searches'] = 'Recherches';
$LANG_VIDEOS['admin_syndication'] = 'Syndication';
$LANG_VIDEOS['admin_test_query_invalid'] = 'La requête de test est invalide.';
$LANG_VIDEOS['admin_catch_up_process_inventories_public_pages_sends'] = 'Le rattrapage inventorie les pages publiques et les envoie à IndexNow en mode batch.';
$LANG_VIDEOS['admin_channel_calls'] = 'Appels chaînes';
$LANG_VIDEOS['admin_developer_information'] = 'Informations développeur';
$LANG_VIDEOS['admin_invalid_youtube_id_url'] = 'ID ou URL YouTube invalide.';
$LANG_VIDEOS['admin_channels'] = 'Chaînes';
$LANG_VIDEOS['admin_rebuild_permanent_catalogue'] = 'Reconstruire le catalogue permanent';
$LANG_VIDEOS['admin_failure_s'] = ' échec(s).';
$LANG_VIDEOS['admin_persistent_public_content_exposed_through_geeklog_item'] = 'Les contenus publics persistants sont exposés via l’API ItemInfo de Geeklog.';
$LANG_VIDEOS['admin_maintenance'] = 'Maintenance';
$LANG_VIDEOS['admin_no_public_videos_url_submit'] = 'Aucune URL publique Videos à signaler.';
$LANG_VIDEOS['admin_needs_review'] = 'À vérifier';
$LANG_VIDEOS['admin_channel_ranking'] = 'Classement chaînes';
$LANG_VIDEOS['admin_pin'] = 'Épingler';
$LANG_VIDEOS['admin_add_api_key'] = 'Ajouter une clé API';
$LANG_VIDEOS['admin_allow_again'] = 'Réautoriser';
$LANG_VIDEOS['admin_api_key_missing'] = 'Clé API absente.';
$LANG_VIDEOS['admin_none'] = 'Aucune';
$LANG_VIDEOS['admin_test_video'] = 'Vidéo test';
$LANG_VIDEOS['admin_replace_key'] = 'Remplacer la clé';
$LANG_VIDEOS['admin_suspension_after_quota_error_reported_by_youtube'] = 'Suspension après une erreur de quota signalée par YouTube';
$LANG_VIDEOS['admin_active_d2f1'] = 'Active';
$LANG_VIDEOS['admin_view_catalogue'] = 'Voir le catalogue';
$LANG_VIDEOS['admin_videos_plugin_storage_unavailable'] = 'Le stockage du plugin Videos est indisponible.';
$LANG_VIDEOS['admin_searchable_videos'] = 'Vidéos recherchables';
$LANG_VIDEOS['admin_video_seo_c7b7'] = 'SEO vidéo';
$LANG_VIDEOS['admin_complete'] = 'À compléter';
$LANG_VIDEOS['admin_global_ranking'] = 'Classement global';
$LANG_VIDEOS['admin_active_editorial_decisions'] = 'Décisions éditoriales actives';
$LANG_VIDEOS['admin_all'] = 'Tous';
$LANG_VIDEOS['admin_seed_query_invalid'] = 'La requête d’amorçage est invalide.';
$LANG_VIDEOS['admin_ranked_channels'] = 'Chaînes classées';
$LANG_VIDEOS['admin_available'] = 'Disponible';
$LANG_VIDEOS['admin_local_discovery_corpus'] = 'Corpus de découverte local';
$LANG_VIDEOS['admin_reservoir_seeding_failed'] = 'L’amorçage du réservoir a échoué.';
$LANG_VIDEOS['admin_indexnow_plugin_unavailable_no_fake_content_creation'] = 'Le plugin IndexNow n’est pas disponible. Aucune fausse création de contenu n’a été émise.';
$LANG_VIDEOS['admin_channels_list_details'] = 'Détails channels.list';
$LANG_VIDEOS['admin_repair_tools'] = 'Outils de réparation';
$LANG_VIDEOS['admin_rankings_rebuilt'] = 'Classements reconstruits : ';
$LANG_VIDEOS['admin_permanent_catalogue_rebuild_failed'] = 'La reconstruction du catalogue permanent a échoué.';
$LANG_VIDEOS['admin_api_key_configured'] = 'Clé API configurée.';
$LANG_VIDEOS['admin_no_retained_video'] = 'Aucune vidéo conservée.';
$LANG_VIDEOS['admin_status_db27'] = 'État';
$LANG_VIDEOS['admin_xml_sitemap'] = 'XML Sitemap';
$LANG_VIDEOS['admin_channels_from_local_ranking'] = 'Chaînes issues du classement local';
$LANG_VIDEOS['admin_unable_add_video_permanent_catalogue'] = 'Impossible d’ajouter la vidéo au catalogue permanent.';
$LANG_VIDEOS['admin_clear_cache'] = 'Vider le cache';
$LANG_VIDEOS['admin_remove_from_selection'] = 'Retirer de la sélection';
$LANG_VIDEOS['admin_video_ranking'] = 'Classement vidéos';
$LANG_VIDEOS['admin_ranked_video_s'] = ' vidéo(s) classée(s).';
$LANG_VIDEOS['admin_today'] = ' aujourd’hui).';
$LANG_VIDEOS['admin_rss_atom_feeds_through_geeklog_native_syndication'] = 'Flux RSS/Atom via le moteur de syndication natif de Geeklog.';
$LANG_VIDEOS['admin_security_token_has_expired_please_try_again'] = 'Le jeton de sécurité a expiré. Veuillez recommencer.';
$LANG_VIDEOS['admin_add_video_directly_by_its_youtube_id'] = 'Ajoutez directement une vidéo par son ID ou son URL YouTube. Elle est récupérée, mise en cache, ajoutée au catalogue permanent puis signalée via les événements Geeklog.';
$LANG_VIDEOS['admin_save_key'] = 'Enregistrer la clé';
$LANG_VIDEOS['admin_videos'] = 'Vidéos';
$LANG_VIDEOS['admin_see_statistics_youtube_api_activity_diagnostics'] = 'Consultez Statistiques > Activité YouTube API pour le diagnostic.';
$LANG_VIDEOS['admin_excluded_from_pool'] = 'Exclues du fonds';
$LANG_VIDEOS['admin_active_1a31'] = 'Actives';
$LANG_VIDEOS['admin_geeklog_statistics'] = 'Statistiques Geeklog';
$LANG_VIDEOS['admin_valid_video_s_found'] = ' vidéo(s) valide(s) trouvée(s).';
$LANG_VIDEOS['admin_entries'] = 'Entrées';
$LANG_VIDEOS['admin_indexnow_batch_could_not_be_sent'] = 'Le batch IndexNow n’a pas pu être envoyé.';
$LANG_VIDEOS['admin_unable_save_decision'] = 'Impossible d’enregistrer cette décision.';
$LANG_VIDEOS['admin_permanent_catalogue_has_been_rebuilt'] = 'Le catalogue permanent a été reconstruit.';
$LANG_VIDEOS['admin_latest_entry'] = 'Entrée la plus récente';
$LANG_VIDEOS['admin_reservoir'] = 'Réservoir';
$LANG_VIDEOS['admin_statistics'] = 'Statistiques';
$LANG_VIDEOS['admin_daily_limit_configured_videos'] = 'Plafond quotidien configuré dans Videos';
// End Videos 0.19.0 semantic administration strings
